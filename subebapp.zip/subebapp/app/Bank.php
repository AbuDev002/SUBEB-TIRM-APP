<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
     protected $primaryKey = 'bank_id';
      public function teacher(){
    	return $this->hasMany('App\Teacher','bank_id');
    }
}
