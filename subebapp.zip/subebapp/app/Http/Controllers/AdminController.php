<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
//use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;
use App\User;


class AdminController extends Controller
{
    //
    public function dashBoard(){
    	return view('admins.dashboard');
    }

    public function usersList(){
    	$users = User::paginate(10);
    	/*$users = Roles::('users as U')
			->leftjoin('role_users as R','U.id','=','R.user_id')
			->Where(['R.role_id' => 3])
			->get();*/
    	return view('admins.userslist')->withUsers($users);
    }

    public function emailsPage(){
    	return view('admins.adminemails');
    }


       public function postMail(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'subject' => 'required|min:3',
            'message' => 'required|min:10',
            ]);

        $data = array(
                 'email' => $request->email,
                 'emailto' => $request->emailto,
                'subject' => $request->subject,
                'bodyMessage' => $request->message,
            );

        Mail::send('admins.emails.messages', $data, function($message) use ($data){
                $message-> from($data['email']);
                $message->to($data['emailto']);
                $message->subject($data['subject']);

        });

        Session::flash('success','Mail has been Sent');
        return redirect()->intended('/admindashboard');
    }
   
     public function register(){
         $schools = School::all();
    	return view('admins.create_users')->withSchools($schools);
    }

    public function postRegister(Request $request){
        $user = Sentinel::registerAndActivate($request->all());
    	//$user = Sentinel::register($request->all());

        //$activation = Activation::create($user);

    	$role = Sentinel::findRoleBySlug($request->input('user_type'));

    	$role->users()->attach($user);
        //$this->sendEmail($user, $activation->code);*/
    	//return redirect('/register');
        return redirect('/createuser')->with('success','User account created');
    }

}
