<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AllocationsController extends Controller
{
    //Admin Allocations method begins heer
    public function allocationPage(){
    	return view('admins.allocations.adminallocations');
    }

    //admin allocation methods ends heer

}
