<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Verification;
use Mail;

class ExternalSchoolManagersController extends Controller
{
    //
    public function dashBoard(){
    	return view('external_schoolmanagers.dashboard');
    }

     public function ExSchoolemailsPage(){
    	return view('external_schoolmanagers.schoolemails');
    }


       public function ExSchoolpostMail(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'subject' => 'required|min:3',
            'message' => 'required|min:10',
            ]);

        $data = array(
                 'email' => $request->email,
                 'emailto' => $request->emailto,
                'subject' => $request->subject,
                'bodyMessage' => $request->message,
            );

        Mail::send('external_schoolmanagers.emails.messages', $data, function($message) use ($data){
                $message-> from($data['email']);
                $message->to($data['emailto']);
                $message->subject($data['subject']);

        });

        Session::flash('success','Mail has been Sent');
        return redirect()->intended('/externalmanager');
    }
   
}
