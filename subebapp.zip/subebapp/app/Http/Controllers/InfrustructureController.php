<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
//use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;

class InfrustructureController extends Controller
{
    //Admin Infrusturcture methods start here
		//this method display infrustructures and project done by SUBEB
    public function InfrsuctructuresList(){
        $infru = Infrustructure::all();
    	return view('admins.infrustructures.admininfrustructure')->withInfrus($infru);
    }

    public function createInfrustructure(){
            $schools = School::all();
            return view('admins.infrustructures.newinfrustructure')->withSchools($schools);
    }

    public function storeInfrustructure(Request $request){
            $infru = new Infrustructure;
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->sponsored = $request->sponsored;
            $infru->yearawarded = $request->yearawarded;
            $infru->contractor = $request->contractor;
            
            $infru->save();

            Session::flash('success','Infrustructure/Facility record added successfully');
            return redirect()->intended('/newinfrustructure');
    }

    public function viewInfrustructure($id){
        $infru = Infrustructure::find($id);
        return view('admins.infrustructures.infrudetails')->withInfru($infru);
    }

    public function editInfrustructure($id){
        $infru = Infrustructure::find($id);
        $school = School::all();
        return view('admins.infrustructures.editinfrustructure')->withInfru($infru)->withSchools($school);
    }

    public function updateInfrustructure(Request $request, $id){
            $infru =Infrustructure::find($id);
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->yearawarded = $request->yearawarded;
            $infru->sponsored = $request->sponsored;
            $infru->contractor = $request->contractor;

            $infru->save();
            Session::flash('success','Infrustructure/Facility Updated Successfully');
            return redirect()->route('customizeinfru',$infru->inf_id);
    }

    //Admin infrustructure methods stoped here


     //Super Admin Infrusturcture methods start here
        //this method display infrustructures and project done by SUBEB
    public function sInfrsuctructuresList(){
        $infru = Infrustructure::all();
        return view('superadmins.infrustructures.admininfrustructure')->withInfrus($infru);
    }

    public function screateInfrustructure(){
            $schools = School::all();
            return view('superadmins.infrustructures.newinfrustructure')->withSchools($schools);
    }

    public function sstoreInfrustructure(Request $request){
            $infru = new Infrustructure;
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->sponsored = $request->sponsored;
            $infru->yearawarded = $request->yearawarded;
            $infru->contractor = $request->contractor;
            
            $infru->save();

            Session::flash('success','Infrustructure/Facility record added successfully');
            return redirect()->intended('/snewinfrustructure');
    }

    public function sviewInfrustructure($id){
        $infru = Infrustructure::find($id);
        return view('superadmins.infrustructures.infrudetails')->withInfru($infru);
    }

    public function seditInfrustructure($id){
        $infru = Infrustructure::find($id);
        $school = School::all();
        return view('superadmins.infrustructures.editinfrustructure')->withInfru($infru)->withSchools($school);
    }

    public function supdateInfrustructure(Request $request, $id){
            $infru =Infrustructure::find($id);
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->yearawarded = $request->yearawarded;
            $infru->sponsored = $request->sponsored;
            $infru->contractor = $request->contractor;

            $infru->save();
            Session::flash('success','Infrustructure/Facility Updated Successfully');
            return redirect()->route('custominfru',$infru->inf_id);
    }

//Super Admin infrustructure methods stoped here

//School Infrusturcture methods start here
        //this method display infrustructures and project done by SUBEB
    public function SchoolInfrsuctructuresList(){
        $infru = Infrustructure::where('sch_id', Sentinel::getUser()->sch_id)->get();
        return view('school_managers.infrustructures.schoolinfrustructure')->withInfrus($infru);
    }

    public function SchoolcreateInfrustructure(){
            $schools = School::all();
            return view('school_managers.infrustructures.newinfrustructure')->withSchools($schools);
    }

    public function SchoolstoreInfrustructure(Request $request){
            $infru = new Infrustructure;
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->sponsored = $request->sponsored;
            $infru->yearawarded = $request->yearawarded;
            $infru->contractor = $request->contractor;
            
            $infru->save();

            Session::flash('success','Infrustructure/Facility record added successfully');
            return redirect()->intended('/schoolnewinfrustructure');
    }

    public function SchoolviewInfrustructure($id){
        $infru = Infrustructure::find($id);
        return view('school_managers.infrustructures.infrudetails')->withInfru($infru);
    }

    public function SchooleditInfrustructure($id){
        $infru = Infrustructure::find($id);
        $school = School::all();
        return view('school_managers.infrustructures.editinfrustructure')->withInfru($infru)->withSchools($school);
    }

    public function SchoolupdateInfrustructure(Request $request, $id){
            $infru =Infrustructure::find($id);
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->yearawarded = $request->yearawarded;
            $infru->sponsored = $request->sponsored;
            $infru->contractor = $request->contractor;

            $infru->save();
            Session::flash('success','Infrustructure/Facility Updated Successfully');
            return redirect()->route('schoolcustomizeinfru',$infru->inf_id);
    }

    //School infrustructure methods stoped here


    // External School Infrusturcture methods start here
        //this method display infrustructures and project done by SUBEB
    public function ExSchoolInfrsuctructuresList(){
        $infru = Infrustructure::where('sch_id', Sentinel::getUser()->sch_id)->get();
        return view('external_schoolmanagers.infrustructures.schoolinfrustructure')->withInfrus($infru);
    }

    public function ExSchoolcreateInfrustructure(){
            $schools = School::all();
            return view('external_schoolmanagers.infrustructures.newinfrustructure')->withSchools($schools);
    }

    public function ExSchoolstoreInfrustructure(Request $request){
            $infru = new Infrustructure;
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->sponsored = $request->sponsored;
            $infru->yearawarded = $request->yearawarded;
            $infru->contractor = $request->contractor;
            
            $infru->save();

            Session::flash('success','Infrustructure/Facility record added successfully');
            return redirect()->intended('/exschoolnewinfrustructure');
    }

    public function ExSchoolviewInfrustructure($id){
        $infru = Infrustructure::find($id);
        return view('external_schoolmanagers.infrustructures.infrudetails')->withInfru($infru);
    }

    public function ExSchooleditInfrustructure($id){
        $infru = Infrustructure::find($id);
        $school = School::all();
        return view('external_schoolmanagers.infrustructures.editinfrustructure')->withInfru($infru)->withSchools($school);
    }

    public function ExSchoolupdateInfrustructure(Request $request, $id){
            $infru =Infrustructure::find($id);
            $infru->projectorinf_name = $request->projectorinf_name;
            $infru->sch_id = $request->sch_id;
            $infru->project_description = $request->project_description;
            $infru->no_of_items = $request->no_of_items;
            $infru->yearawarded = $request->yearawarded;
            $infru->sponsored = $request->sponsored;
            $infru->contractor = $request->contractor;

            $infru->save();
            Session::flash('success','Infrustructure/Facility Updated Successfully');
            return redirect()->route('exschoolcustomizeinfru',$infru->inf_id);
    }

    // External School infrustructure methods stoped here
}
