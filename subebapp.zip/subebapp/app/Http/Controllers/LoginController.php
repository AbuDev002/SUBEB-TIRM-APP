<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Sentinel;
use Cartalyst\Sentinel\Checkpoints\ThrottlingException;
use Cartalyst\Sentinel\Checkpoints\NotActivatedException;

class LoginController extends Controller
{
    //
    public function login(){
    	return view('authentication.login');
    }

    public function postLogin(Request $request){
       /* $role = Sentinel::findRoleById(1);
            $role->permissions = [
                'posts.create' => true,
            ];

            $role->save();*/
       try{
            $rememberMe = false;
            if(isset($request->remember_me))
                $rememberMe = true;
                 if(Sentinel::authenticate($request->all(), $rememberMe)){
                $slug = Sentinel::getUser()->roles()->first()->slug;
                //here am going to use ajax response to redirect users to their specific pages
                        if($slug=='admin')
                            return response()->json(['redirect' => '/admindashboard']);
                        elseif($slug == 'super_admin')
                            return response()->json(['redirect' => '/superadmin']);
                         elseif($slug == 'school_manager')
                            return response()->json(['redirect' => '/schoolmanager']);
                         elseif($slug == 'external_manager')
                            return response()->json(['redirect' => '/externalmanager']);
                }else{
                    //return redirect()->back()->with(['error' => 'Incorrect Email or Password!']);
                    return response()->json(['error' => 'Incorrect Email or Password!'],500);
            } 
       }catch(ThrottlingException $e){
            $delay = $e->getDelay();
             return response()->json(['error' => "You have been banned for $delay seconds."],500);
       }catch(NotActivatedException $e){
             return response()->json(['error' => "Your account has not been activated yet!"],500);
       }

    }

    public function logout(){
    	Sentinel::logout();
    	return redirect('/login');
    }
}
