<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
//use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;
use App\User;
use \PDF;
use App\Bank;


class PDFController extends Controller
{
   
//All admin PDFs Starts Here
    public function AllstaffgetPDF(){
    	$teachers = Teacher::all();
    	$pdf = PDF::loadView('admins.reports.teachers',['teachers' =>$teachers]);
    	return $pdf->download('teachers.pdf');
    }
//schools based on lga report
    public function getLgaPDF(Request $request){
    	$lga = $request->input('lga');
    	$schools = School::where('lga',$lga)->get();
    	$pdf = PDF::loadView('admins.reports.schoolsinlga',['schools' =>$schools, 'lga'=>$lga]);
    	return $pdf->download('listoflgaschools.pdf');
    }

 //Teachers and their bank report
    public function getBanksPDF(Request $request){
    	$bank = $request->input('bank_id');
        $bnks = Bank::where('bank_id',$bank)->get();
    	$teachers = Teacher::where('bank_id',$bank)->get();
    	$pdf = PDF::loadView('admins.reports.staffsinbank',['teachers' =>$teachers, 'bank'=>$bank, 'bnks'=>$bnks]);
    	return $pdf->download('listofstaffsinbank.pdf');
    }

 //list of staffs serving in a particular school
    public function getSchoolsPDF(Request $request){
    	$school = $request->input('school');
    	$schs = School::where('sch_id',$school)->get();
    	$teachers = Teacher::where('present_school',$school)->get();
    	$pdf = PDF::loadView('admins.reports.staffsinschool',['teachers' =>$teachers, 'school'=>$school, 'schs'=>$schs]);
    	return $pdf->download('listofteachers.pdf');
    }

//list of staffs based on their qualification
    public function getQualificationPDF(Request $request){
    	$qualif = $request->input('typeofqualification');
    	$teachers = Teacher::where('typeofqualification',$qualif)->get();
    	$pdf = PDF::loadView('admins.reports.staffsbyqualification',['teachers' =>$teachers, 'qualif'=>$qualif]);
    	return $pdf->download('listofstaffs.pdf');
    }
//All admin PDFs Stoped Here

//Super admin pdfs Starts Here
 public function sAllstaffgetPDF(){
        $teachers = Teacher::all();
        $pdf = PDF::loadView('superadmins.reports.teachers',['teachers' =>$teachers]);
        return $pdf->download('teachers.pdf');
    }
//schools based on lga report
    public function sgetLgaPDF(Request $request){
        $lga = $request->input('lga');
        $schools = School::where('lga',$lga)->get();
        $pdf = PDF::loadView('superadmins.reports.schoolsinlga',['schools' =>$schools, 'lga'=>$lga]);
        return $pdf->download('listoflgaschools.pdf');
    }

 //Teachers and their bank report
    public function sgetBanksPDF(Request $request){
        $bank = $request->input('bank_id');
        $bnks = Bank::where('bank_id',$bank)->get();
        $teachers = Teacher::where('bank_id',$bank)->get();
        $pdf = PDF::loadView('superadmins.reports.staffsinbank',['teachers' =>$teachers, 'bank'=>$bank, 'bnks'=>$bnks]);
        return $pdf->download('listofstaffsinbank.pdf');
    }

 //list of staffs serving in a particular school
    public function sgetSchoolsPDF(Request $request){
        $school = $request->input('school');
        $schs = School::where('sch_id',$school)->get();
        $teachers = Teacher::where('present_school',$school)->get();
        $pdf = PDF::loadView('superadmins.reports.staffsinschool',['teachers' =>$teachers, 'school'=>$school, 'schs'=>$schs]);
        return $pdf->download('listofteachers.pdf');
    }

//list of staffs based on their qualification
    public function sgetQualificationPDF(Request $request){
        $qualif = $request->input('typeofqualification');
        $teachers = Teacher::where('typeofqualification',$qualif)->get();
        $pdf = PDF::loadView('superadmins.reports.staffsbyqualification',['teachers' =>$teachers, 'qualif'=>$qualif]);
        return $pdf->download('listofstaffs.pdf');
    }

//Super admin PDFs Stoped Here
}
