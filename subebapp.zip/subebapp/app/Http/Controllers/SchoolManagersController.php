<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Mail;

class SchoolManagersController extends Controller
{
    //
    public function dashBoard(){
    	return view('school_managers.dashboard');
    }

     public function SchoolemailsPage(){
    	return view('school_managers.schoolemails');
    }


       public function SchoolpostMail(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'subject' => 'required|min:3',
            'message' => 'required|min:10',
            ]);

        $data = array(
                 'email' => $request->email,
                 'emailto' => $request->emailto,
                'subject' => $request->subject,
                'bodyMessage' => $request->message,
            );

        Mail::send('school_managers.emails.messages', $data, function($message) use ($data){
                $message-> from($data['email']);
                $message->to($data['emailto']);
                $message->subject($data['subject']);

        });

        Session::flash('success','Mail has been Sent');
        return redirect()->intended('/schoolmanager');
    }
   

}
