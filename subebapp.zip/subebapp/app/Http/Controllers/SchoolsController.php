<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
//use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;

class SchoolsController extends Controller
{
   
    //Admin School Methods Begins Here

//this method display list of schools under subeb
    public function SchoolsList(){
        $schools = School::orderBy('sch_id','desc')->paginate(10);
        return view('admins.schools.schoolspage')->withSchools($schools);
    }

    //this method display the school form
    public function addSchool(){
         return view('admins.schools.addnewschool');
    }
//this method is going to add new school record
    public function postSchool(Request $request){
       //
        $school = new School;
        $school->school_name = $request->school_name;
        $school->lga = $request->lga;
        $school->sch_location= $request->sch_location;
        $school->save();
        Session::flash('success','School has been added successfully');
        return redirect()->intended('/adminschool');
    }

//this method will display specific teacher's record
    public function viewSchool($id){
        //$teacher = Teachers::find($id);
        $school = School::where('sch_id', '=', $id)->first();
        $teachers = Teacher::where('present_school',$id)->paginate(10);
        $infrus = Infrustructure::where('sch_id',$id)->get();
        return view('admins.schools.schooldetails')->withSchool($school)->withTeachers($teachers)->withInfrus($infrus);
    }

    public function editSchool($id){
        $school = School::find($id);
        return view('admins.schools.editschool')->withSchool($school);

    }

    public function updateSchool(Request $request, $id){
            $school =School::find($id);
            $school->school_name = $request->school_name;
            $school->lga = $request->lga;
            $school->sch_location = $request->sch_location;

            $school->save();
            Session::flash('success','Record Updated Successfully');
            return redirect()->route('customschool',$school->sch_id);
    }
    //Admin School Methods Ends Here



     //Super Admin School Methods Begins Here

//this method display list of schools under subeb
    public function sSchoolsList(){
        $schools = School::orderBy('sch_id','desc')->paginate(10);
        return view('superadmins.schools.schoolspage')->withSchools($schools);
    }

    //this method display the school form
    public function saddSchool(){
         return view('superadmins.schools.addnewschool');
    }
//this method is going to add new school record
    public function spostSchool(Request $request){
       //
        $school = new School;
        $school->school_name = $request->school_name;
        $school->lga = $request->lga;
        $school->sch_location= $request->sch_location;
        $school->save();
        Session::flash('success','School has been added successfully');
        return redirect()->intended('/sadminschool');
    }

//this method will display specific teacher's record
    public function sviewSchool($id){
        //$teacher = Teachers::find($id);
        $school = School::where('sch_id', '=', $id)->first();
        $teachers = Teacher::where('present_school',$id)->paginate(10);
        $infrus = Infrustructure::where('sch_id',$id)->get();
        return view('superadmins.schools.schooldetails')->withSchool($school)->withTeachers($teachers)->withInfrus($infrus);
    }

    public function seditSchool($id){
        $school = School::find($id);
        return view('superadmins.schools.editschool')->withSchool($school);

    }

    public function supdateSchool(Request $request, $id){
            $school =School::find($id);
            $school->school_name = $request->school_name;
            $school->lga = $request->lga;
            $school->sch_location = $request->sch_location;

            $school->save();
            Session::flash('success','Record Updated Successfully');
            return redirect()->route('scustomschool',$school->sch_id);
    }

    //delete school and its record
    public function sdeleteSchool($id){
        $delteach = School::findOrFail($id);
        $delteach->delete();
        Session::flash('success','School Deleted Successfully');
        return redirect('/sadminschool');
    }
    //Super Admin School Methods Ends Here

}
