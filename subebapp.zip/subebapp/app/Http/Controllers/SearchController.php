<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Teacher;
use DB;
use School;
use Sentinel;

class SearchController extends Controller
{
    //admin search methods begins here
    public function getAdminSearchResult(Request $request){

    	$query = $request->input('admin_search');
    	if(!$query){
    		return redirect('/admindashboard');
    	}

    	$teachers = Teacher::where(DB::raw("CONCAT(firstname,' ',surname)"), 'LIKE', "%{$query}%")->orWhere('email', 'LIKE',"%{$query}%")->orWhere('teacher_no', 'LIKE',"%{$query}%")->get();
    	return view('admins.search.searchresult')->withTeachers($teachers);
    }

    //admin school search methods begins here
    public function getAdminSchoolSearchResult(Request $request){
        $output ="";
        //$query = $request->search_school;
        if($request->ajax()){
             // $schools = School::where(DB::raw('school_name', 'LIKE', "%{$query}%")->orWhere('lga', 'LIKE',"%{$query}%"))->get();
            $schools = DB::table('schools')->where('school_name', 'LIKE','%'.$request->search_school.'%')->orWhere('lga', 'LIKE', '%'.$request->search_school.'%')->get();

            if($schools){
                foreach($schools as $school){
                    $output.='<tr>'.
                             '<td>'.$school->school_name.'</td>'.
                             '<td>'.$school->lga.'</td>'.
                             '<td><a href="/viewschool/'.$school->sch_id.'" class="btn btn-default btn-sm">View Details</a></td>'.
                             '<td><a href="/editschool/'.$school->sch_id.'/editschool" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span></a></td>'.
                             '</tr>';
                }
                 return Response($output);
            }else{
                 return Response()->json(['No'=> 'record found']);
                //$schools = School::orderBy('sch_id','desc')->paginate(10);
                //return view('admins.schools.schoolspage')->withSchools($schools);
            }
         //return view('admins.schools.schoolspage')->withSchools($schools);
        
        }
       
    }


     //super admin search methods begins here
    public function sgetAdminSearchResult(Request $request){

    	$query = $request->input('sadmin_search');
    	if(!$query){
    		return redirect('/superadmin');
    	}

    	$teachers = Teacher::where(DB::raw("CONCAT(firstname,' ',surname)"), 'LIKE', "%{$query}%")->orWhere('email', 'LIKE',"%{$query}%")->orWhere('teacher_no', 'LIKE',"%{$query}%")->get();
        return view('superadmins.search.searchresult')->withTeachers($teachers);
    }

     //super admin school search methods begins here
    public function getsAdminSchoolSearchResult(Request $request){
        $output ="";
        //$query = $request->search_school;
        if($request->ajax()){
             // $schools = School::where(DB::raw('school_name', 'LIKE', "%{$query}%")->orWhere('lga', 'LIKE',"%{$query}%"))->get();
            $schools = DB::table('schools')->where('school_name', 'LIKE','%'.$request->search_school.'%')->orWhere('lga', 'LIKE', '%'.$request->search_school.'%')->get();

            if($schools){
                foreach($schools as $school){
                    $output.='<tr>'.
                             '<td>'.$school->school_name.'</td>'.
                             '<td>'.$school->lga.'</td>'.
                             '<td><a href="/sviewschool/'.$school->sch_id.'" class="btn btn-default btn-sm">View Details</a></td>'.
                             '<td><a href="/seditschool/'.$school->sch_id.'/editschool" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span></a></td>'.
                             '<td>
                                <form action="/sremoveschool/'.$school->sch_id.'">
                                '.csrf_field().'
                                '.method_field("DELETE").'
                                    <button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span></button>
                            </form>
                            </td>'.
                             '</tr>';
                }
                 return Response($output);
            }else{
                 return Response()->json(['No'=> 'record found']);
                //$schools = School::orderBy('sch_id','desc')->paginate(10);
                //return view('admins.schools.schoolspage')->withSchools($schools);
            }
         //return view('admins.schools.schoolspage')->withSchools($schools);
        
        }
       
    }


     //school manager search methods begins here
    public function getSchoolSearchResult(Request $request){

        $query = $request->input('school_search');
        if(!$query){
            return redirect('/schoolmanager');
        }

        $teachers = Teacher::where(DB::raw("CONCAT(firstname,' ',surname)"), 'LIKE', "%{$query}%")->orWhere('email', 'LIKE',"%{$query}%")->orWhere('teacher_no', 'LIKE',"%{$query}%")->Where('present_school', '=',Sentinel::getUser()->sch_id)->get();
        return view('school_managers.search.searchresult')->withTeachers($teachers);
    }


     //external school manager search methods begins here
    public function ExgetSchoolSearchResult(Request $request){

        $query = $request->input('exschool_search');
        if(!$query){
            return redirect('/exschoolmanager');
        }

        $teachers = Teacher::where(DB::raw("CONCAT(firstname,' ',surname)"), 'LIKE', "%{$query}%")->orWhere('email', 'LIKE',"%{$query}%")->orWhere('teacher_no', 'LIKE',"%{$query}%")->Where('present_school', '=',Sentinel::getUser()->sch_id)->get();
        return view('external_schoolmanagers.search.searchresult')->withTeachers($teachers);
    }
}
