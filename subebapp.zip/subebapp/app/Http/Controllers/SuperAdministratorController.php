<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
//use App\Http\Request;
use Sentinel;
use App\User;
use Mail;
use Session;
use App\state;
use App\School;
class SuperAdministratorController extends Controller
{
    //
    public function dashBoard(){
    	return view('superadmins.dashboard');
    }

     public function usersPage(){
     	 //$user = Sentinel::getUser();
     	$user = User::paginate(10);
        //return redirect('/userpage')
    	return view('superadmins.userspage')->with('listofUsers', $user);
    }

    //this method will edit user details
    public function editUser($id){
        $user = User::find($id);
        $school = School::all();
        return view('superadmins.edituser')->withUser($user)->withSchools($school);
    }

   //delete User or School Account
    public function sdeleteUser($id){
        $deluser = User::findOrFail($id);
        $deluser->delete();
        Session::flash('success','User Deleted Successfully');
        return redirect('/userspage');
    }

     public function sendMail(){
        return view('superadmins.sendemail');
    }


    public function postMail(Request $request){
        $this->validate($request, [
            'email' => 'required|email',
            'subject' => 'required|min:3',
            'message' => 'required|min:10',
            ]);

        $data = array(
                 'email' => $request->email,
                 'emailto' => $request->emailto,
                'subject' => $request->subject,
                'bodyMessage' => $request->message,
            );

        Mail::send('superadmins.emails.messages', $data, function($message) use ($data){
                $message-> from($data['email']);
                $message->to($data['emailto']);
                $message->subject($data['subject']);

        });

        Session::flash('success','Mail has been Sent');
        return redirect()->intended('/superadmin');
    }
}
