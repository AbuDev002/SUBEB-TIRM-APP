<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;
use App\Bank;
class TeachersController extends Controller
{
    
    //Admin Teachers Methods Begins Here
    //this method display list of teachers
    public function TeachersList(){
        $teachers = Teacher::orderBy('id','desc')->paginate(10);
        return view('admins.teachers.teachers')->withTeachers($teachers);
    }

//this method display a form for adding a new teacher
    public function addTeacher(){
        $state = state::all();
        $schools = School::all();
        $banks = Bank::all();
        return view('admins.teachers.addnewteacher')->withState($state)->withSchools($schools)->withBanks($banks);
    }

//this method is adding teacher record to the database
    public function storeTeacher(Request $request){
         // validate the data
        $this->validate($request, array(
                'teacher_no' => 'required|unique:teachers',
                'surname' => 'required',
                'firstname' => 'required',
                'passport' => 'sometimes|image',
                'gender' => 'required',
                'religion' => 'required',
                'marital_status' => 'required',
                'dob' => 'required',
                'placeofbirth' => 'required',
                'state' => 'required',
                'lga' => 'required',
                'contact_address' => 'required',
                'phone' => 'required',
                'email' => 'required|unique:teachers',
                'residential_address' => 'required',
                'nok_name' => 'required',
                'nok_relation' => 'required',
                'nok_address' => 'required',
                'nok_phone' => 'required',
                'typeofqualification' => 'required',
                'dateofenlistment' => 'required',
                'status' => 'required',
                'bank_id' => 'required',
                'bank_address' => 'required',
                'account_name' => 'required',
                'account_no' => 'required|min:10|max:10'
            ));

        // store in the database
        $teacher = new Teacher;
        $teacher->teacher_no = $request->teacher_no;
        $teacher->passport = $request->passport;
        $teacher->surname = $request->surname;
        $teacher->firstname = $request->firstname;
        $teacher->othername = $request->othername;
        $teacher->gender = $request->gender;
        $teacher->religion = $request->religion;
        $teacher->marital_status = $request->marital_status;
        $teacher->dob = $request->dob;
        $teacher->placeofbirth = $request->placeofbirth;
        $teacher->state = $request->state;
        $teacher->lga = $request->lga;
        $teacher->contact_address = $request->contact_address;
        $teacher->phone = $request->phone;
        $teacher->email = $request->email;
        $teacher->residential_address = $request->residential_address;
        $teacher->nok_name = $request->nok_name;
        $teacher->nok_relation = $request->nok_relation;
        $teacher->nok_address = $request->nok_address;
        $teacher->nok_phone = $request->nok_phone;
        $teacher->present_school = $request->present_school;
        $teacher->typeofqualification = $request->typeofqualification;
        $teacher->dateofenlistment = $request->dateofenlistment;
        $teacher->previous_school = $request->previous_school;
        $teacher->status = $request->status;
        $teacher->bank_id = $request->bank_id;
        $teacher->bank_address = $request->bank_address;
        $teacher->account_name = $request->account_name;
        $teacher->account_no = $request->account_no;

        if ($request->hasFile('passport')) {
          $image = $request->file('passport');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/upload',$filename);
          $teacher->passport = $filename;
        }

        $teacher->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Teacher has been added successfully');
        return redirect('/newteacher');
    }

//this method will display specific teacher's record
    public function viewTeacher($id){
        //$teacher = Teachers::find($id);
        $teacher = Teacher::find($id);
        /*$schools = Schools::all();
        $sch = array();
        foreach ($schools as $school) {
            $sch[$school->id] = $school->school_name;
        }*/
        return view('admins.teachers.teacherdetails')->withTeacher($teacher);
    }
//this method is display teachers form for editing
    public function editTeacher($id){
        $teacher = Teacher::find($id);
        $state = state::all();
        $school = School::all();
        $banks = Bank::all();
        return view('admins.teachers.editteacherdetails')->withTeacher($teacher)->withState($state)->withSchools($school)->withBanks($banks);
    }

//This method updates a specific teacher record
     public function updateTeacher(Request $request, $id){
        // validate the data
        $this->validate($request, array(
                'teacher_no' => 'required',
                'surname' => 'required',
                'firstname' => 'required',
                'gender' => 'required',
                'religion' => 'required',
                'marital_status' => 'required',
                'dob' => 'required',
                'placeofbirth' => 'required',
                'state' => 'required',
                'lga' => 'required',
                'contact_address' => 'required',
                'phone' => 'required',
                'email' => 'required',
                'residential_address' => 'required',
                'nok_name' => 'required',
                'nok_relation' => 'required',
                'nok_address' => 'required',
                'nok_phone' => 'required',
                'typeofqualification' => 'required',
                'dateofenlistment' => 'required',
                'status' => 'required',
                'bank_id' => 'required',
                'bank_address' => 'required',
                'account_name' => 'required',
                'account_no' => 'required|min:10|max:10'
            ));

        // store in the database
        $teacher =Teacher::find($id);
        $teacher->teacher_no = $request->teacher_no;
        $teacher->passport = $request->passport;
        $teacher->surname = $request->surname;
        $teacher->firstname = $request->firstname;
        $teacher->othername = $request->othername;
        $teacher->gender = $request->gender;
        $teacher->religion = $request->religion;
        $teacher->marital_status = $request->marital_status;
        $teacher->dob = $request->dob;
        $teacher->placeofbirth = $request->placeofbirth;
        $teacher->state = $request->state;
        $teacher->lga = $request->lga;
        $teacher->contact_address = $request->contact_address;
        $teacher->phone = $request->phone;
        $teacher->email = $request->email;
        $teacher->residential_address = $request->residential_address;
        $teacher->nok_name = $request->nok_name;
        $teacher->nok_relation = $request->nok_relation;
        $teacher->nok_address = $request->nok_address;
        $teacher->nok_phone = $request->nok_phone;
        $teacher->present_school = $request->present_school;
        $teacher->typeofqualification = $request->typeofqualification;
        $teacher->dateofenlistment = $request->dateofenlistment;
        $teacher->previous_school = $request->previous_school;
        $teacher->status = $request->status;
        $teacher->bank_id = $request->bank_id;
        $teacher->bank_address = $request->bank_address;
        $teacher->account_name = $request->account_name;
        $teacher->account_no = $request->account_no;

        if ($request->hasFile('passport')) {
          $image = $request->file('passport');
          $nfilename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/upload',$nfilename);
          //the old image
          $oldFilename = $teacher->passport; 
          //updating the image in the database
          $teacher->passport = $nfilename;
          //deleting the oldimage
          Storage::delete($oldFilename);
        }

        $teacher->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Record Updated Successfully');
        return redirect()->route('updated',$teacher->id);
     }
    //Admin Teachers Method Ends Here


// Super Admin Teachers Methods Begins Here
    //this method display list of teachers
    public function sTeachersList(){
        $teachers = Teacher::orderBy('id','desc')->paginate(10);
        return view('superadmins.teachers.teachers')->withTeachers($teachers);
    }

//this method display a form for adding a new teacher
    public function saddTeacher(){
        $state = state::all();
        $schools = School::all();
        $banks = Bank::all();
        return view('superadmins.teachers.addnewteacher')->withState($state)->withSchools($schools)->withBanks($banks);
    }

//this method is adding teacher record to the database
    public function sstoreTeacher(Request $request){
         // validate the data
        $this->validate($request, array(
                'teacher_no' => 'required|unique:teachers',
                'surname' => 'required',
                'firstname' => 'required',
                'passport' => 'sometimes|image',
                'gender' => 'required',
                'religion' => 'required',
                'marital_status' => 'required',
                'dob' => 'required',
                'placeofbirth' => 'required',
                'state' => 'required',
                'lga' => 'required',
                'contact_address' => 'required',
                'phone' => 'required',
                'email' => 'required|unique:teachers',
                'residential_address' => 'required',
                'nok_name' => 'required',
                'nok_relation' => 'required',
                'nok_address' => 'required',
                'nok_phone' => 'required',
                'typeofqualification' => 'required',
                'dateofenlistment' => 'required',
                'status' => 'required',
                'bank_id' => 'required',
                'bank_address' => 'required',
                'account_name' => 'required',
                'account_no' => 'required|min:10|max:10'
            ));

        // store in the database
        $teacher = new Teacher;
        $teacher->teacher_no = $request->teacher_no;
        $teacher->passport = $request->passport;
        $teacher->surname = $request->surname;
        $teacher->firstname = $request->firstname;
        $teacher->othername = $request->othername;
        $teacher->gender = $request->gender;
        $teacher->religion = $request->religion;
        $teacher->marital_status = $request->marital_status;
        $teacher->dob = $request->dob;
        $teacher->placeofbirth = $request->placeofbirth;
        $teacher->state = $request->state;
        $teacher->lga = $request->lga;
        $teacher->contact_address = $request->contact_address;
        $teacher->phone = $request->phone;
        $teacher->email = $request->email;
        $teacher->residential_address = $request->residential_address;
        $teacher->nok_name = $request->nok_name;
        $teacher->nok_relation = $request->nok_relation;
        $teacher->nok_address = $request->nok_address;
        $teacher->nok_phone = $request->nok_phone;
        $teacher->present_school = $request->present_school;
        $teacher->typeofqualification = $request->typeofqualification;
        $teacher->dateofenlistment = $request->dateofenlistment;
        $teacher->previous_school = $request->previous_school;
        $teacher->status = $request->status;
        $teacher->bank_id = $request->bank_id;
        $teacher->bank_address = $request->bank_address;
        $teacher->account_name = $request->account_name;
        $teacher->account_no = $request->account_no;

        if ($request->hasFile('passport')) {
          $image = $request->file('passport');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/upload',$filename);
          $teacher->passport = $filename;
        }

        $teacher->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Teacher has been added successfully');
        return redirect('/snewteacher');
    }

//this method will display specific teacher's record
    public function sviewTeacher($id){
        //$teacher = Teachers::find($id);
        $teacher = Teacher::find($id);
        /*$schools = Schools::all();
        $sch = array();
        foreach ($schools as $school) {
            $sch[$school->id] = $school->school_name;
        }*/
        return view('superadmins.teachers.teacherdetails')->withTeacher($teacher);
    }
//this method is display teachers form for editing
    public function seditTeacher($id){
        $teacher = Teacher::find($id);
        $state = state::all();
        $school = School::all();
        $banks = Bank::all();
        return view('superadmins.teachers.editteacherdetails')->withTeacher($teacher)->withState($state)->withSchools($school)->withBanks($banks);
    }

//This method updates a specific teacher record
     public function supdateTeacher(Request $request, $id){
        // validate the data
        $this->validate($request, array(
                'teacher_no' => 'required',
                'surname' => 'required',
                'firstname' => 'required',
                'gender' => 'required',
                'religion' => 'required',
                'marital_status' => 'required',
                'dob' => 'required',
                'placeofbirth' => 'required',
                'state' => 'required',
                'lga' => 'required',
                'contact_address' => 'required',
                'phone' => 'required',
                'email' => 'required',
                'residential_address' => 'required',
                'nok_name' => 'required',
                'nok_relation' => 'required',
                'nok_address' => 'required',
                'nok_phone' => 'required',
                'typeofqualification' => 'required',
                'dateofenlistment' => 'required',
                'status' => 'required',
                'bank_id' => 'required',
                'bank_address' => 'required',
                'account_name' => 'required',
                'account_no' => 'required|min:10|max:10'
            ));

        // store in the database
        $teacher =Teacher::find($id);
        $teacher->teacher_no = $request->teacher_no;
        $teacher->passport = $request->passport;
        $teacher->surname = $request->surname;
        $teacher->firstname = $request->firstname;
        $teacher->othername = $request->othername;
        $teacher->gender = $request->gender;
        $teacher->religion = $request->religion;
        $teacher->marital_status = $request->marital_status;
        $teacher->dob = $request->dob;
        $teacher->placeofbirth = $request->placeofbirth;
        $teacher->state = $request->state;
        $teacher->lga = $request->lga;
        $teacher->contact_address = $request->contact_address;
        $teacher->phone = $request->phone;
        $teacher->email = $request->email;
        $teacher->residential_address = $request->residential_address;
        $teacher->nok_name = $request->nok_name;
        $teacher->nok_relation = $request->nok_relation;
        $teacher->nok_address = $request->nok_address;
        $teacher->nok_phone = $request->nok_phone;
        $teacher->present_school = $request->present_school;
        $teacher->typeofqualification = $request->typeofqualification;
        $teacher->dateofenlistment = $request->dateofenlistment;
        $teacher->previous_school = $request->previous_school;
        $teacher->status = $request->status;
        $teacher->bank_id = $request->bank_id;
        $teacher->bank_address = $request->bank_address;
        $teacher->account_name = $request->account_name;
        $teacher->account_no = $request->account_no;

        if ($request->hasFile('passport')) {
          $image = $request->file('passport');
          $nfilename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/upload',$nfilename);
          //the old image
          $oldFilename = $teacher->passport; 
          //updating the image in the database
          $teacher->passport = $nfilename;
          //deleting the oldimage
          Storage::delete($oldFilename);
        }

        $teacher->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Record Updated Successfully');
        return redirect()->route('supdated',$teacher->id);
     }

     //delete teachers record
    public function sdeleteTeacher($id){
        $delteach = Teacher::findOrFail($id);
        $delteach->delete();
        Session::flash('success','Teacher Record Successfully deleted');
        return redirect('/sadminteachers');
    }


    //School Teachers methods starts here
    //this method display list of teachers
    public function SchoolTeachersList(){
        $teachers = Teacher::where('present_school',Sentinel::getUser()->sch_id)->orderBy('id','desc')->paginate(10);
        return view('school_managers.teachers.teachers')->withTeachers($teachers);
    }

    //this method will display specific teacher's record
    public function SchoolviewTeacher($id){
        //$teacher = Teachers::find($id);
        $teacher = Teacher::find($id);
        return view('school_managers.teachers.teacherdetails')->withTeacher($teacher);
    }


//External School Teachers methods starts here
    //this method display list of teachers
    public function ExSchoolTeachersList(){
        $teachers = Teacher::where('present_school',Sentinel::getUser()->sch_id)->orderBy('id','desc')->paginate(10)->first();
        //$user = Schoo::where('sch_id',S)
        //$school = School::where('sch_id',Sentinel::getUser()->sch_id)->first();
        return view('external_schoolmanagers.teachers.teachers')->withTeachers($teachers);
    }

    //this method will display specific teacher's record
    public function ExSchoolviewTeacher($id){
        //$teacher = Teachers::find($id);
        $teacher = Teacher::find($id);
        return view('external_schoolmanagers.teachers.teacherdetails')->withTeacher($teacher);
    }

}
