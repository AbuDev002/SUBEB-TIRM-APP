<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Roles;
use Sentinel;
use DB;
use Mail;
//use Image;
use \Storage;
use Session;
use App\state;
use App\School;
use App\Teacher;
use App\Infrustructure;
use App\Verification;
class VerficationController extends Controller
{
    

    //Admin verification methods starts here
     public function verificationPage(){
        $schools = School::all();
        return view('admins.verifications.adminverification')->withSchools($schools);
    }

     public function postVerification(Request $request){
         // validate the data
        $this->validate($request, array(
                'sender_name' => 'required',
                'sch_id' => 'required',
                'message' => 'required',
                'credential' => 'sometimes'
            ));

        // store in the database
        $verify = new Verification;
        $verify->messagefromschool_id = $request->message_from;
        $verify->sender_name = $request->sender_name;
        $verify->messagetoschool_id  = $request->sch_id;
        $verify->message = $request->message;
        $verify->documents = $request->credential;
        
         if ($request->hasFile('credential')) {
          $image = $request->file('credential');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/verifications',$filename);
          $verify->documents = $filename;
        }

        $verify->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Request has been sent');
        return redirect('/adminverification');
    }


    public function inboxNotificationInadmin(){
    	$verify = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
    	$readinbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->count();
    	return view('admins.verifications.inboxmessages')->withVerfs($verify)->withInboxes($readinbox);
    }

    public function sendboxNotificationInadmin(){
    	$verifysendbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
    	$readsendbox = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->count();
    	return view('admins.verifications.sendboxmessages')->withVerfsendbox($verifysendbox)->withSendboxes($readsendbox);
    }

    public function markAsread(Request $request, $id){
        $updatestatus = Verification::find($id);
        $updatestatus->status = $request->status;
        $updatestatus->save();
        Session::flash('success','Successfully marked as read');
        return redirect('/inbox');

    }

//delete inbox message
    public function deleteInbox($id){
        $delinbox = Verification::findOrFail($id);
        $delinbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/inbox');
    }
    //delet outbox message
    public function deleteOutbox($id){
        $deloutbox = Verification::find($id);
        $deloutbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/sendbox');
    }

    //Admin Verification methods ends here


     //Super Admin verification methods starts here
     public function sverificationPage(){
        $schools = School::all();
        return view('superadmins.verifications.adminverification')->withSchools($schools);
    }
    

     public function spostVerification(Request $request){
         // validate the data
        $this->validate($request, array(
                'sender_name' => 'required',
                'sch_id' => 'required',
                'message' => 'required',
                'credential' => 'sometimes'
            ));

        // store in the database
        $verify = new Verification;
        $verify->messagefromschool_id = $request->message_from;
        $verify->sender_name = $request->sender_name;
        $verify->messagetoschool_id  = $request->sch_id;
        $verify->message = $request->message;
        $verify->documents = $request->credential;
        
         if ($request->hasFile('credential')) {
          $image = $request->file('credential');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/verifications',$filename);
          $verify->documents = $filename;
        }

        $verify->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Request has been sent');
        return redirect('/sadminverification');
    }


    public function sinboxNotificationInadmin(){
        $verify = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readinbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->count();
        return view('superadmins.verifications.inboxmessages')->withVerfs($verify)->withInboxes($readinbox);
    }

    public function ssendboxNotificationInadmin(){
        $verifysendbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readsendbox = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->count();
        return view('superadmins.verifications.sendboxmessages')->withVerfsendbox($verifysendbox)->withSendboxes($readsendbox);
    }

    public function smarkAsread(Request $request, $id){
        $updatestatus = Verification::find($id);
        $updatestatus->status = $request->status;
        $updatestatus->save();
        Session::flash('success','Successfully marked as read');
        return redirect('/sinbox');

    }

//delete inbox message
    public function sdeleteInbox($id){
        $delinbox = Verification::findOrFail($id);
        $delinbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/sinbox');
    }
    //delet outbox message
    public function sdeleteOutbox($id){
        $deloutbox = Verification::find($id);
        $deloutbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/ssendbox');
    }

//Super Admin Verification methods ends here


//School verification methods starts here
     public function SchoolverificationPage(){
        $schools = School::all();
        return view('school_managers.verifications.schoolverification')->withSchools($schools);
    }

     public function SchoolpostVerification(Request $request){
         // validate the data
        $this->validate($request, array(
                'sender_name' => 'required',
                'sch_id' => 'required',
                'message' => 'required',
                'credential' => 'sometimes'
            ));

        // store in the database
        $verify = new Verification;
        $verify->messagefromschool_id = $request->message_from;
        $verify->sender_name = $request->sender_name;
        $verify->messagetoschool_id  = $request->sch_id;
        $verify->message = $request->message;
        $verify->documents = $request->credential;
        
         if ($request->hasFile('credential')) {
          $image = $request->file('credential');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/verifications',$filename);
          $verify->documents = $filename;
        }

        $verify->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Request has been sent');
        return redirect('/schoolverification');
    }


    public function SchoolinboxNotificationInadmin(){
        $verify = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readinbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->count();
        return view('school_managers.verifications.inboxmessages')->withVerfs($verify)->withInboxes($readinbox);
    }

    public function SchoolsendboxNotificationInadmin(){
        $verifysendbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readsendbox = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->count();
        return view('school_managers.verifications.sendboxmessages')->withVerfsendbox($verifysendbox)->withSendboxes($readsendbox);
    }

    public function SchoolmarkAsread(Request $request, $id){
        $updatestatus = Verification::find($id);
        $updatestatus->status = $request->status;
        $updatestatus->save();
        Session::flash('success','Successfully marked as read');
        return redirect('/schoolinbox');

    }

//delete inbox message
    public function SchooldeleteInbox($id){
        $delinbox = Verification::findOrFail($id);
        $delinbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/schoolinbox');
    }
    //delet outbox message
    public function SchooldeleteOutbox($id){
        $deloutbox = Verification::find($id);
        $deloutbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/schoolsendbox');
    }

//School Verification methods ends here


// External School verification methods starts here
     public function ExSchoolverificationPage(){
        $schools = School::all();
        return view('external_schoolmanagers.verifications.schoolverification')->withSchools($schools);
    }

     public function ExSchoolpostVerification(Request $request){
         // validate the data
        $this->validate($request, array(
                'sender_name' => 'required',
                'sch_id' => 'required',
                'message' => 'required',
                'credential' => 'sometimes'
            ));

        // store in the database
        $verify = new Verification;
        $verify->messagefromschool_id = $request->message_from;
        $verify->sender_name = $request->sender_name;
        $verify->messagetoschool_id  = $request->sch_id;
        $verify->message = $request->message;
        $verify->documents = $request->credential;
        
         if ($request->hasFile('credential')) {
          $image = $request->file('credential');
          $filename = time() . '.' . $image->getClientOriginalExtension();
          //$location = public_path('/images/passports/' . $filename);
          //Image::make($image)->resize(150, 150)->save($location);
          //$uploaded = Storage::putFile($location, file_get_contents($image->getRealPath()));
          $image->storeAs('public/verifications',$filename);
          $verify->documents = $filename;
        }

        $verify->save();
        //$post->tags()->sync($request->tags, false);
         Session::flash('success','Request has been sent');
        return redirect('/exschoolverification');
    }


    public function ExSchoolinboxNotificationInadmin(){
        $verify = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readinbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->count();
        return view('external_schoolmanagers.verifications.inboxmessages')->withVerfs($verify)->withInboxes($readinbox);
    }

    public function ExSchoolsendboxNotificationInadmin(){
        $verifysendbox = Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->orderby('verf_id','desc')->paginate(5);
        $readsendbox = Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->count();
        return view('external_schoolmanagers.verifications.sendboxmessages')->withVerfsendbox($verifysendbox)->withSendboxes($readsendbox);
    }

    public function ExSchoolmarkAsread(Request $request, $id){
        $updatestatus = Verification::find($id);
        $updatestatus->status = $request->status;
        $updatestatus->save();
        Session::flash('success','Successfully marked as read');
        return redirect('/exschoolinbox');

    }

//delete inbox message
    public function ExSchooldeleteInbox($id){
        $delinbox = Verification::findOrFail($id);
        $delinbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/exschoolinbox');
    }
    //delet outbox message
    public function ExSchooldeleteOutbox($id){
        $deloutbox = Verification::find($id);
        $deloutbox->delete();
        Session::flash('success','Successfully deleted');
        return redirect('/exschoolsendbox');
    }

//External School Verification methods ends here
    
}
