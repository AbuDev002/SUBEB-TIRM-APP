<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Sentinel;

class postsController extends Controller
{
    //
    public function store(Request $request){
    	$user = Sentinel::getUser();

    	//for checking multiple permissions use array please example
    	//if($user->hasAccess(['posts.creat','posts.update']))
    	//for checking if one permission is true out of many use this method
    	//if($user->hasAnyAccess(['posts.creat','posts.update']))
    	// to check if all the permisions are true
    	//if($user->hasAccess(['posts.*']))
    	
    	if($user->hasAccess('posts.create'))
    		return $request->all();

    	abort(403, 'Unauthorized action');
    }

}
