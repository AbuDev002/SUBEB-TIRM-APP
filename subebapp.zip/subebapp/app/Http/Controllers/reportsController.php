<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\School;
use App\Bank;
use \PDF;

class reportsController extends Controller
{
    //Admin reports method begins here
    public function reportPage(){
    	$schools = School::all();
    	$banks = Bank::all();
        return view('admins.reports.reportpage')->withSchools($schools)->withBanks($banks);
    }


    //super admin reports
    public function sreportPage(){
        $schools = School::all();
        $banks = Bank::all();
        return view('superadmins.reports.reportpage')->withSchools($schools)->withBanks($banks);
    }
}
