<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class smsController extends Controller
{
    //admin sms methods begins here
     public function smsPage(){
    	return view('admins.sms.adminsms');
    }


    //super admin sms methods begins here
     public function ssmsPage(){
    	return view('superadmins.sms.adminsms');
    }

     //school sms methods begins here
     public function SchoolsmsPage(){
    	return view('school_managers.sms.schoolsms');
    }

    //external school sms methods begins here
     public function ExSchoolsmsPage(){
        return view('external_schoolmanagers.sms.schoolsms');
    }
}
