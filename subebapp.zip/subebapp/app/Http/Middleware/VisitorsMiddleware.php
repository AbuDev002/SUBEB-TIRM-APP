<?php

namespace App\Http\Middleware;

use Closure;
use Sentinel;
use App\User;

class VisitorsMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {   
        if(!Sentinel::check())
            return $next($request);
        else
            $slug = Sentinel::getUser()->roles()->first()->slug;
        if($slug=='admin')
                    return redirect('/admindashboard');
                elseif($slug == 'super_admin')
                    return redirect('/superadmin');
                 elseif($slug == 'school_manager')
                    return redirect('/schoolmanager');
                 elseif($slug == 'external_manager')
                    return redirect('/externalmanager');
            //return redirect('/');
    }
}
