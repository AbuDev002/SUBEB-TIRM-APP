<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Infrustructure extends Model
{
    //
    protected $primaryKey = 'inf_id';
    public function school(){
    	return $this->belongsTo('App\School','sch_id');
    }
}
