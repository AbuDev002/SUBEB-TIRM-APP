<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Schema;
use View;
use App\Verification;
use Sentinel;
class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
        Schema::defaultStringLength(191);
          
        view()->composer(['external_schoolmanagers.menu','admins.menu','superadmins.menu.side','school_managers.menu','school_managers.verifications.verifybox','superadmins.verifications.verifybox','external_schoolmanagers.verifications.verifybox','admins.verifications.verifybox'],function($view){
            $view->with('notify', Verification::where('messagetoschool_id',Sentinel::getUser()->sch_id)->where('status', 0)->get())
            ->with('total_inbox',Verification::where('messagefromschool_id', Sentinel::getUser()->sch_id)->get())
            ->with('total_outbox',Verification::where('messagetoschool_id', Sentinel::getUser()->sch_id)->get());
        });  
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
