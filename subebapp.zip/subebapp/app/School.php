<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class School extends Model
{
    //
    protected $primaryKey = 'sch_id';
    public function teacher()
    {
    	return $this->hasMany('App\Teacher','sch_id');
    }

    public function verification(){
    	return $this->hasMany('App\Verification','sch_id');
    }

    public function infrustructure(){
    	return $this->hasMany('App\Infrustructure','sch_id');
    }

     public function user(){
        return $this->hasMany('App\User','sch_id');
    }
}
