<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Teacher extends Model
{
    protected $table ='teachers';
    public function school()
    {
    	return $this->belongsTo('App\School','present_school');
    	//return School::where('sch_id', $this->present_school)
    }


     public function secondschool()
    {
    	return $this->belongsTo('App\School','previous_school');
    	//return School::where('sch_id', $this->present_school)
    }

    public function bank(){
        return $this->belongsTo('App\Bank','bank_id');
    }
}
