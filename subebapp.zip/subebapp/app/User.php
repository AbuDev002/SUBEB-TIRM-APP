<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Cartalyst\Sentinel\Users\EloquentUser;


class User extends EloquentUser
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email',
        'password',
        'last_name',
        'first_name',
        'permissions',
        'location',
        'sch_id',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public static function byEmail($email){
        return static::whereEmail($email)->first();
    }

    public function role(){
        return $this->belongsToMany('App\User','id');
    }

    public function school(){
        return $this->belongsTo('App\School','sch_id');
    }

    /*public function roles(){
        return $this->belongsToMany('App\Role');
    }*/
}
