<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Verification extends Model
{
    //
    protected $primaryKey = 'verf_id';
    public function school(){

    	return $this->belongsTo('App\School','messagefromschool_id');
    }

    public function secschool(){

    	return $this->belongsTo('App\School','messagetoschool_id');
    }
}
