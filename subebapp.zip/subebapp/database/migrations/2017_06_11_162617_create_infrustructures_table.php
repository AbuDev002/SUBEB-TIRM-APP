<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateInfrustructuresTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('infrustructures', function (Blueprint $table) {
            $table->increments('inf_id');
            $table->string('projectorinf_name');
            $table->integer('sch_id')->unsigned();
            $table->text('project_description')->nullable();
            $table->integer('no_of_items')->nullable();
            $table->string('sponsored')->nullable();
            $table->string('yearawarded');
            $table->string('contractor')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('infrustructures');
    }
}
