<?php
	header('Location:../login');


?>