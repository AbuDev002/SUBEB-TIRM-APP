<h3>You have a new message</h3>

<div>
	{{ $bodyMessage }}
</div>

<p>Email Was Sent via: {{ $email }}</p>