<div class="col-md-3" style="padding-left:40px;">
    <div class="sidebar-nav">
      <div class="navbar navbar-default" role="navigation">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <span class="visible-xs navbar-brand">Sidebar menu</span>
        </div>
        <div class="navbar-collapse collapse sidebar-navbar-collapse">
          <ul class="nav navbar-nav">
            <li class="{{Request::is('adminfrustructures') ? "active" : ""}}"><a href="/adminfrustructures" class="btn btn-default btn-sm"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp; &nbsp;</i><span class="text-info" style="font-size:16px">Infrastructure</span></a></li>
            <li class="{{Request::is('adminsms') ? "active" : ""}}"><a href="http://www.gwanisoftware.com/sales/gwanisms.html" target="_blank" class="btn btn-default btn-sm"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp; &nbsp;</i><span class="text-info" style="font-size:16px">SMS</span></a></li>
            <li class="{{Request::is('adminemails') ? "active" : ""}}"><a href="/adminemails" class="btn btn-default btn-sm"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp; &nbsp;</i><span class="text-info" style="font-size:16px">Send Email</span></a></li>
            <li class="{{Request::is('adminverification') ? "active" : ""}}"><a href="/adminverification" class="btn btn-default btn-sm"><i class="fa fa-hand-o-right" aria-hidden="true">&nbsp; &nbsp;</i> <span class="text-info" style="font-size:16px">Verifications</span>&nbsp;<span class="badge">{!! $notify->count() !!}</span></a></li>
            <!-- <li class="#"><a href="/adminallocation" class="btn btn-default btn-sm"> <i class="fa fa-hand-o-right" aria-hidden="true">&nbsp; &nbsp;</i><span class="text-info" style="font-size:16px">Allocations</span></a></li> -->
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </div>
  </div>