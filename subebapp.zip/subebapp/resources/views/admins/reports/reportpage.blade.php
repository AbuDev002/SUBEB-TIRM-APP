@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Generate Reports</font>
	</div>
	<div class="panel-body">
	<p><a href="/adminallstaffpdf" class="btn btn-default btn-sm">Get All Teachers</a></p>
	<hr>
		<div class="row">
		<div class="col-md-6">
			<div class="panel panel-default">
			<form action="/adminstafflgapdf">
				{{ csrf_field()}}
				<div class="panel-body">
				
				<p>School Report By LGA</p>
					<div class="form-group">
							<div class="input-group">
								
									
									<label for="sel1">LGA:</label>
									
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
								<select class="form-control" id="sel1" name="lga" required>
								    <option>--Select--</option>
								    <option value="Alkaleri">Alkaleri</option>
								    <option value="Bauchi">Bauchi</option>
								    <option value="Bogoro">Bogoro</option>
								    <option value="Dambam">Dambam</option>
								    <option value="Darazo">Darazo</option>
								    <option value="Dass">Dass</option>
								    <option value="Ganjuwa">Ganjuwa</option>
								    <option value="Gamawa">Gamawa</option>
								    <option value="Giade">Giade</option>
								    <option value="Itas/Gadau">Itas/Gadau</option>
								    <option value="Jama'are">Jama'are</option>
								    <option value="Katagum">Katagum</option>
								    <option value="Kirfi">Kirfi</option>
								    <option value="Misau">Misau</option>
								    <option value="Ningi">Ningi</option>
								    <option value="Shira">Shira</option>
								    <option value="Tafawa-Balewa">Tafawa-Balewa</option>
								    <option value="Toro">Toro</option>
								    <option value="Warji">Warji</option>
								    <option value="Zaki">Zaki</option>
								</select>
								
							</div>

						</div>
						
				</div>
				<br>
				<div class="panel-footer" style="padding:0px;height:30px;">
					<button type="submit" class="btn btn-default btn-sm pull-right">Get Report</button>
				</div>
				</form>
			</div>
		</div>
		<div class="col-md-6">
			<div class="panel panel-default">
			<form action="/adminbankspdf">
				{{ csrf_field()}}
				<div class="panel-body">
				<p>Teachers Report By Bank</p>
					<div class="form-group">
							<div class="input-group">
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
							
								<label for="sel1">Bank:</label>
									<select class="form-control" id="sel1" name="bank_id" required>
								    	<option>--Select--</option>
								    	 @foreach($banks as $bank)
		                                    <option value="{{ $bank->bank_id}}">{{ $bank->bank_name}}</option>
		                               	 @endforeach
									</select>
							</div>
						</div>
				</div>
				<div class="panel-footer" style="padding:0px;height:30px;">
					<button type="submit" class="btn btn-default btn-sm pull-right">Get Report</button>
				</div>
				</form>
			</div>
		</div>
		</div>
		<div class="row">
			
			<div class="col-md-6">
				<div class="panel panel-default">
				<form action="/adminqualificationspdf">
					{{ csrf_field()}}
					<div class="panel-body">
					<p>Teachers Report By Qualification</p>
						<div class="form-group">
							
							<label for="sel1">Qualification:</label>
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
							<select class="form-control" name="typeofqualification" style="width:50%;" required>
                                <option value="">---Select--</option>
                                <option value="Bsc/HND">Bsc./HND</option>
                                <option value="OND/ND">OND/ND</option>
                                <option value="NCE">NCE</option>
                                <option value="SSCE">SSCE</option>
                            </select>
						</div>
					</div>
					<div class="panel-footer" style="padding:0px;height:30px;">
						<button type="submit" class="btn btn-default btn-sm pull-right">Get Report</button>
					</div>
				</form>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel panel-default">
					<form action="/adminschoolpdf">
						{{ csrf_field()}}
					<div class="panel-body">
					<p>Teachers Report By School Serving</p>
						<div class="form-group">
							<div class="input-group">
							
									<label for="sel1">School:</label>
									<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
									<select class="form-control" id="sel1" name="school" required>
									    <option>--Select--</option>
									    @foreach($schools as $school)
		                                    <option value="{{ $school->sch_id}}">{{ $school->school_name}}</option>
		                                @endforeach
									</select>
								
							</div>
						</div>
					</div>
					<div class="panel-footer" style="padding:0px;height:30px;">
						<button type="submit" class="btn btn-default btn-sm pull-right">Get Report</button>
					</div>
				</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection