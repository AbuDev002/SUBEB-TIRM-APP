<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Report</title>
	<link rel="stylesheet" href="/css/bootstrap.css" />
	<link rel="stylesheet" href="/css/bootstrap-min.css" />

<style type="text/css">
	.page-break {
	    page-break-after: always;
	}
	#container{
		width:750px;
		height:auto;
		margin:0px auto;
		text-indent:5px;
                       
	}
	
	table{
		border-collapse: collapse;
	}
	.head{
	background:#91C5D4;
	}
	@page { margin: 180px 50px; }
	#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 135px; background-color: #f5f5f5; text-align: center; width:100%; }
	#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 45px; background-color: #f5f5f5; }
	#footer .page:after { content: counter(page, upper-roman); }
/*p { page-break-after: always; }*/
	.footer { position: fixed; bottom: 0px; }
	.pagenum:before { content: counter(page); }
  
</style>
</head>
<body>
<div id="header">
	<table  align="center"  width="100%">
		<tr>
			
			<td colspan="3" align="center"><h3>BAUCHI STATE UNIVERSAL BASIC EDUCATION BOARD<br/> <i> Ran Road, Near Awala Hotel Roundabout Bauchi, Bauchi State PMB 0109</i></h3></td>
		</tr>
		<tr>
			<td colspan="3" align="center" width="50">
				<?php $image_path = '/images/logo.jpg'; ?>
				<img src="{{ public_path() . $image_path }}" with="50" height="50">
			</td>
		</tr>
	</table>
</div>
<div id="footer">
		<hr/>
		{{date('Y/m/d')}} / &nbsp; &nbsp; Page: <span class="pagenum">
</div>	
	<div id="container">
			@foreach($schs as $sch)

			@endforeach
			<center><p><b><u>Teachers Serving in {{$sch->school_name}} as at ({{date('Y-m-d')}})</u></b></p></center>
			<table class="table table-bordered" align="center" border="1" width="90%">
				<tr>
					<td width="20"><b>S/N</b></td>
					<td width="50"><b>PSN No.</b></td>
					<td><b>Name</b></td>
					<td><b>Sex</b></td>
					<td><b>Phone</b></td>
				</tr>
				 <?php $i = 0 ?>
				@forelse($teachers as $teacher)
				<?php $i++ ?>
				<tr>
					<td>{{ $i }}</td>
					<td>{{ $teacher->teacher_no}}</td>
					<td>{{ $teacher->surname}} {{ $teacher->firstname}} {{ $teacher->othername}}</td>
					<td>{{ $teacher->gender}}</td>
					<td>{{ $teacher->phone}}</td>
				</tr>

				@empty
				<br>
					<center><p>No Teacher Available</p></center>
				@endforelse
			</table>
	</div>
</body>
</html>