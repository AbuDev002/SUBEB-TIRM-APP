@extends('layouts.admin_template')
@section('admins-content')

			<div class="panel panel-default">
				<div class="panel-heading special">
					&nbsp; &nbsp; <font color="white"> Add New School</font>
				</div>
				<div class="panel-body">
					
						<div class="row">
							<div class="col-md-6 col-md-offset-3">
								<div class="well well-sm">
						{{ Form::model($school, ['url' => ['/editschool', $school->sch_id]]) }} 
						@if(session('success'))
						<div class="alert alert-success">
							{{ session('success') }}
						</div>
						@endif
						<div class="form-group">
							<div class="input-group">
								<label for="sel1">Name of School:</label>
								<!-- <input type="text" name="school_name" class="form-control" placeholder="Enter school name..." required> -->
								{{ Form::text('school_name',null, ["style" => 'width:100%']) }}
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
							<label for="sel1">LGA:</label>
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
								<select class="form-control" id="sel1" name="lga" required>
								    <option>{{ $school->lga}}</option>
								    <option value="Alkaleri">Alkaleri</option>
								    <option value="Bauchi">Bauchi</option>
								    <option value="Bogoro">Bogoro</option>
								    <option value="Dambam">Dambam</option>
								    <option value="Darazo">Darazo</option>
								    <option value="Dass">Dass</option>
								    <option value="Ganjuwa">Ganjuwa</option>
								    <option value="Gamawa">Gamawa</option>
								    <option value="Giade">Giade</option>
								    <option value="Itas/Gadau">Itas/Gadau</option>
								    <option value="Jama'are">Jama'are</option>
								    <option value="Katagum">Katagum</option>
								    <option value="Kirfi">Kirfi</option>
								    <option value="Misau">Misau</option>
								    <option value="Ningi">Ningi</option>
								    <option value="Shira">Shira</option>
								    <option value="Tafawa-Balewa">Tafawa-Balewa</option>
								    <option value="Toro">Toro</option>
								    <option value="Warji">Warji</option>
								    <option value="Zaki">Zaki</option>
								  </select>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<label for="sel1">Location/Address:</label>
								<!--<input type="text" name="sch_location" class="form-control" placeholder="Enter location..." required>-->
								 <!-- <textarea name="sch_location" class="form-control" style="height:100px;" required></textarea> -->
								 {{ Form::textarea('sch_location',null, ["style" => 'width:100%;','rows' =>'4']) }}
							</div>
						</div>
						<div class="form-group">
								<button type="submit" class="btn btn-default">Update School Record</button>
						</div>
					{!! Form::close() !!} 
								</div>
							</div>
						</div>
					
				</div>
			</div>
@endsection