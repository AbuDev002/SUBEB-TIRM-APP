@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Search Result</font>
	</div>
	<div class="panel-body">
		<p>Your search for "{{ Request::input('school_search')}}"</p>

		<table class="table table-bordered">
			@forelse($schools as $school)
				<tr>
					<td>{{ $school->school_name}}</td>
					<td>{{ $school->lga}}</td>
					<td><a href="/viewteacher/{{ $school->sch_id }}" class="btn btn-default btn-sm">View Details</a></td>
					<td><a href="/editteacher/{{ $school->sch_id }}/editTeacher" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span>Edit</a></td>
				</tr>
			@empty
				<p class="text-danger">No result found, sorry</p>
			
			@endforelse
		</table>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection