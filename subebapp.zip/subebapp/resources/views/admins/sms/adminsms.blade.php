@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">SMS Alert</font>
	</div>
	<div class="panel-body">
		
	</div>
</div>
@endsection

@section('scripts')
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()
			

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
@endsection