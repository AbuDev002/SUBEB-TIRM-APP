@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Teacher's Detail</font> 
	</div>
	<div class="panel-body">
		
	 	<table class="table table-condensed table-bordered">
             <tr>
             	<td colspan="5"><b>Personal Details</b> <a href="/editteacher/{{ $teacher->id }}/editTeacher" class="btn btn-default btn-sm pull-right"><span class="glyphicon glyphicon-edit"></span>Edit Record</a></td>

             </tr>               
			<tr>
				<td rowspan="6" width="150">
					@if(!empty($teacher->passport))
						<img src="{{asset('storage/upload/' . $teacher->passport)}}" class="img-thumbnail" width="150" height="150" />
					@else
						@if($teacher->gender =='Male')
							<img src="/images/avarter.png" class="img-thumbnail" width="150" height="150" />

						@else
							<img src="/images/feavarter.png" class="img-thumbnail" width="150" height="150" />
						@endif
					@endif
				</td>
				<th>PSN</th>
				<td>{{ $teacher->teacher_no }}</td>
			</tr>
			<tr>
				<th>Full Name</th>
				<td>{{ $teacher->surname }} {{ $teacher->firstname }} {{ $teacher->othername }}</td>
			</tr>
			
			<tr>
				<th>Sex</th>
				<td>{{ $teacher->gender }}</td>
				
			</tr>
	        <tr>
				<th width="250">Religion</th>
				<td>{{ $teacher->religion }}</td>
				
			</tr>
			<tr>
				<th width="250">Marital Status</th>
				<td>{{ $teacher->marital_status}}</td>
				
			</tr>
			<tr>
				<th width="250">Date of Birth</th>
				<td>{{ $teacher->dob }}</td>
				
			</tr>
			<tr>
				<td></td>
				<th width="250">Place of Birth</th>
				<td>{{ $teacher->placeofbirth }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">State</th>
				<td>{{ $teacher->state }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">LGA</th>
				<td>{{ $teacher->lga }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Mobile Phone</th>
				<td>{{ $teacher->phone }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Contact Address</th>
				<td>{{ $teacher->contact_address }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">E-mail</th>
				<td>{{ $teacher->email }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Residential Address</th>
				<td>{{ $teacher->residential_address }}</td>
			</tr>
			<tr>
				<td colspan="5"><b>Next of Kin Details</b></td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Next of Kin Name</th>
				<td>{{ $teacher->nok_name }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Next of Kin Relationship</th>
				<td>{{ $teacher->nok_relation }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Next of Kin Address</th>
				<td>{{ $teacher->nok_address }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Next of Kin Phone</th>
				<td>{{ $teacher->nok_phone }}</td>
			</tr>
			<tr>
				<td colspan="5"><b>Educational Details</b></td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Type of Qualification</th>
				<td>{{ $teacher->typeofqualification }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Present School</th>
				<td>{{ $teacher->school->school_name }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Date of Enlistment</th>
				<td> {{ $teacher->dateofenlistment }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Previous School</th>
				<td>{{ $teacher->secondschool->school_name }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Status</th>
				<td>{{ $teacher->status }}</td>
			</tr>
			<tr>
				<td colspan="5"><b>Bank Details</b></td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Bank Name</th>
				<td>{{ $teacher->bank->bank_name }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Bank Address</th>
				<td>{{ $teacher->bank_address }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Account Name</th>
				<td>{{ $teacher->account_name }}</td>
			</tr>
			<tr>
				<td></td>
				<th width="250">Account No.</th>
				<td>{{ $teacher->account_no }}</td>
			</tr>
			
		</table>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection