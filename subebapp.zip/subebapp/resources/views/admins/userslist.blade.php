@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">List of Users</font>
	</div>
	<div class="panel-body">
		<ol class="breadcrumb">
			  <li><a href="/createuser">Add User</a></li>
			  <li>This are uses creaded by the Administrator</li>
			</ol>
			<table class="table table-bordered">
				@foreach ($users as $user)
				<tr>
					<td>{{ $user->email }}</td>
					<td>{{ $user->first_name }}</td>
					<td>{{ $user->school['school_name'] }}</td>
					<!-- <td><a href="/removeuser/id" class="btn btn-default btn-sm">Delete</a></td> -->
					<!-- <td><a href="#" class="btn btn-default btn-sm">View</a></td> -->
				</tr>
				@endforeach
			</table>
			{{ $users->links() }}
	</div>
</div>

@endsection

@section('scripts')
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()
			

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
@endsection