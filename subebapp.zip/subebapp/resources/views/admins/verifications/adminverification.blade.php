@extends('layouts.admin_template')
@section('admins-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Staffs Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			@include('admins.verifications.verifybox')
			<div class="col-md-9">
				<div class="well well-sm">
					<form action="/adminverification" method="post" enctype="multipart/form-data" data-parsley-validate>
						{{ csrf_field()}}
						@if(session('success'))
						<div class="alert alert-success">
							{{ session('success') }}
						</div>
						@endif
						<hr/>
						<input type="hidden" name="message_from" value="{{ Sentinel::getUser()->sch_id}}">
						<table class="table table-bordered" style="width:100%">
							<tr>
								<td align="right"><b>Sender Name:</b></td>
								<td><input type="text" name="sender_name" placeholder="Enter sender name..." style="width:100%;" required></td>
							</tr>
							
							<tr>
								<td align="right"><b>School to Send Request:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option>--Select School--</option>
								    	@foreach($schools as $school)
											<option value="{{ $school->sch_id}}">{{ $school->school_name }}</option>

								    	@endforeach
								 	</select>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Message:</b></td>
								<td>
									<textarea name="message" placeholder="Write message..." style="height:100px; width:100%;"></textarea>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Staff Credentials:</b></td>
								<td>
									<input type="file" name="credential">
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default btn-block">Send Verification</button>
								</td>
							</tr>
						</table>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()
			

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
@endsection