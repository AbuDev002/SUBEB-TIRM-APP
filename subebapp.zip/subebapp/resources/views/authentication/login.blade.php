@extends('layouts.master')

@section('content')
<br>
<br>
<br>
<div class="container" style="border:1px solid silver;background:#fff; padding:0px;">
<br>
		<div class="row" style="padding:0px;">
			<div class="col-md-3"></div>
			<div class="col-md-6" style="height:140px">
			
				<center>
					<img src="images/sbt.jpg" class="img-responsive" style="height:140px" width="100%">
				</center>
				
			</div>
			<div class="col-md-3"></div>			
		</div>
	<br>
	<div class="row">
		<div class="col-md-4"></div>
		<div class="col-md-4">
			<div class="panel panel-default">
			<div class="alert alert-success" style="display:none;">
							Successfully Login Redirecting...
						</div>
				<div class="panel-heading topbar">
					<h3 class="panel-title"><img src="images/key.png" width="30" height="30"> <font color="white">Enter your login details</font></h3>
				</div>
				<div class="panel-body">
					<form id="login-form">
					
						<div class="alert alert-danger" style="display:none;">
							
						</div>
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
								<input type="email" name="email" class="form-control" placeholder="example@example.com" autocomplete="off" required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock fa-lg"></i></span>
								<input type="password" name="password" class="form-control" placeholder="Enter password..." required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<input type="checkbox" name="remember_me">&nbsp; Remember me next time.
								
							</div>
						</div>
						<p><a href="/forgot-password">Forgot Your Password?</a></p>
						
								<button type="submit" class="btn btn-default btn-block">Click to login</button>
						
					</form>
				</div>
			</div>
			<hr/>
			<center><p class="text-info" style="font-size:12px;">Copyright &copy; {{ date('Y') }} All Rights Reserved SUBEB Bauchi</p></center>
		</div>
		<div class="col-md-4"></div>
	</div>
</div>
@endsection

@section('scripts')
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
@endsection