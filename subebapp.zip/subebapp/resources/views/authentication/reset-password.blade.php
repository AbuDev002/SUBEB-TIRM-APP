@extends('layouts.master')

@section('content')
<br>
<br>
<br>
<div class="contaier" style="border:1px solid silver;background:#fff; padding:0px;">
<br>
<div class="row" style="padding:0px;">
			<div class="col-md-3"></div>
			<div class="col-md-6" style="height:140px">
			
				<center>
					<img src="images/sbt.jpg" class="img-responsive" style="height:140px" width="100%">
				</center>
				
			</div>
			<div class="col-md-3"></div>			
		</div>
<br>	
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<div class="panel panel-default">
				<div class="panel-heading topbar">
					<h3 class="panel-title">Forgot Password</h3>
				</div>
				<div class="panel-body">
					<form action="" method="post">
					@if(count('errors') > 0)
						<div class="alert alert-danger">
							<ul>
								@foreach($errors->all() as $error)
								<li>{{ $error }}</li>
								@endforeach
							</ul>
						</div>
					@endif
					
						{{ csrf_field()}}
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="password" class="form-control" placeholder="Enter password..." required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="password_confirmation" class="form-control" placeholder="Comfirm password..." required>
								
							</div>
						</div>
						<div class="form-group">
								<button type="submit" class="btn btn-default pull-right">Update Password</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection