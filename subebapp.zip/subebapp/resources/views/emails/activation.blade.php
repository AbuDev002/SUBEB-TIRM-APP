<h1>Hello</h1>
<p>Plese click on the following link to activate your account
<a href="{{ env('APP_URL') }}/activate/{{ $user->email }}/{{ $code }}">activate account</a>
</p>