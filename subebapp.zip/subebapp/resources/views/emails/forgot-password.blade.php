<h1>Hello</h1>
<p>Plese click on the following link to reset your password
<a href="{{ env('APP_URL') }}/reset/{{ $user->email }}/{{ $code }}">Click here!</a>
</p>