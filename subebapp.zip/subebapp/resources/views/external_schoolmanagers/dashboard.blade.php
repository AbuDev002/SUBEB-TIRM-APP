@extends('layouts.exmanager_template')
@section('exmanager-content')
External School Managers dashboard
@endsection

@section('scripts')
	
@endsection