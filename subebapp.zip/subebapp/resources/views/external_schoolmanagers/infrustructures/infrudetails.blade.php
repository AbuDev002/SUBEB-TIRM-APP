@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Infrastructure Details</font>
	</div>
	<div class="panel-body">
		<ol class="breadcrumb">
		  <li><a href="/exschoolnewinfrustructure">Add Infrastructure</a></li>
		</ol>
		<hr/>
		
			<div class="media">
				<p><b>{{ $infru->projectorinf_name}}</b></p>
				<div class="media-body">
					<div class="well">
						<p><b>School Awarded</b> {{ $infru->school->school_name}}</p>
						<p><b>Sponsored By:</b> {{ $infru->sponsored}}</p>
						<hr>
						<p><b>Project Description</b></p>
						<p>{{ $infru->project_description}}</p>
					</div>
				</div>
				<div class="media-footer">
					<div class="row">
					<div class="col-md-4"></div>
					<div class="col-md-8"> 
						<ol class="breadcrumb bcs">
			             	<li><b>Year Awarded:</b> {{ $infru->yearawarded}}</li> 
			             	<li><b>Contractor:</b> {{ $infru->contractor}}</li> 
			            </ol>
            		</div>
				</div>
				</div>
			</div>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection