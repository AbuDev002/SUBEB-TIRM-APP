@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Search Result</font>
	</div>
	<div class="panel-body">
		<p>Your search for "{{ Request::input('exschool_search')}}"</p>

		<table class="table table-bordered">
			@forelse($teachers as $teacher)
				<tr>
					<td>{{ $teacher->teacher_no}}</td>
					<td>{{ $teacher->firstname}} {{ $teacher->surname}}</td>
					<td>{{ $teacher->email}}</td>
					<td><a href="/exschoolviewteacher/{{ $teacher->id }}" class="btn btn-default btn-sm">View Details</a></td>
				</tr>
			@empty
				<p class="text-danger">No result found, sorry</p>
			
			@endforelse
		</table>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection