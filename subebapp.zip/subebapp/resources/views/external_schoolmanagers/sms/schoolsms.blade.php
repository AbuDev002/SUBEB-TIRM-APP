@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">SMS Alert</font>
	</div>
	<div class="panel-body">
		
	</div>
</div>
@endsection

@section('scripts')
	
@endsection