@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">DashBoard</font> 
	</div>
	<div class="panel-body">
	@if(session('success'))
	<div class="alert alert-success">
		{{ session('success') }}
	</div>
	@endif
		
	</div>
</div>
@endsection

@section('scripts')
	
@endsection