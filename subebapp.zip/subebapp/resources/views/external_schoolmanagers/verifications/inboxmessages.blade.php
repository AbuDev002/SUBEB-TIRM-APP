@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Notification Messages For Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			@include('external_schoolmanagers.verifications.verifybox')
			<div class="col-md-9">
			@if(session('success'))
			<div class="alert alert-success">
				{{ session('success') }}
			</div>
			@endif
				<div class="panel-body">
					@forelse($verfs as $verf)
						<div class="media pull-right">
							<p><b>Send From:</b> {{ $verf->sender_name }}</p>
							<div class="media-body">
								<div class="well">
									{{ $verf->message }}
								</div>
							</div>
							<div class="media-footer">
								<div class="row">
									<div class="col-md-4"></div>
									<div class="col-md-8"> 
									<ol class="breadcrumb bcs">
						              <li>
						              	 <form action="/exschoolremoveinboxmsg/{{$verf->verf_id}}">
							              	{{ csrf_field() }}
							              	{{ method_field('DELETE') }}
												<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span> Trash </button>
										  </form>
						              </li>
						              <li>
						              <form action="/markasreadmsg/{{$verf->verf_id}}">
							              	{{ csrf_field() }}
							              	{{ method_field('PUT') }}
							              	<input type="hidden" name="status" value="1">
							              	 {!! ($verf->status == 0) ? '<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-check"></span>Mark As Read</button>' :  '<button class="btn btn-success btn-sm" disabled="disabled"><span class=""></span>Viewed</button>'!!}
							              	
						              </form>
						              </li>
						              <li>
										@if(!empty($verf->documents))
						              <a href="{{asset('storage/verifications/' . $verf->documents)}}" download="{{ $verf->documents }}" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-download"></span> Download</a>
										@endif
						              </li>
						            </ol>
				            		</div>
								</div>
								
							</div>
						</div>
						<hr>
						@empty
						 No request available.
						@endforelse
						{{ $verfs->links()}}
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection