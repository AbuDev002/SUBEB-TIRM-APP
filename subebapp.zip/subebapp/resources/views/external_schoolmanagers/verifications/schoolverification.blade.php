@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Staffs Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			@include('external_schoolmanagers.verifications.verifybox')
			<div class="col-md-9">
				<div class="well well-sm">
					<form action="/exschoolverification" method="post" enctype="multipart/form-data" data-parsley-validate>
						{{ csrf_field()}}
						@if(session('success'))
						<div class="alert alert-success">
							{{ session('success') }}
						</div>
						@endif
						<hr/>
						<input type="hidden" name="message_from" value="{{ Sentinel::getUser()->sch_id}}">
						<table class="table table-bordered" style="width:100%">
							<tr>
								<td align="right"><b>Sender Name:</b></td>
								<td><input type="text" name="sender_name" placeholder="Enter sender name..." style="width:100%;" required></td>
							</tr>
							
							<tr>
								<td align="right"><b>School to Send Request:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option>--Select School--</option>
								    	@foreach($schools as $school)
											<option value="{{ $school->sch_id}}">{{ $school->school_name }}</option>

								    	@endforeach
								 	</select>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Message:</b></td>
								<td>
									<textarea name="message" placeholder="Write message..." style="height:100px; width:100%;"></textarea>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Staff Credentials:</b></td>
								<td>
									<input type="file" name="credential">
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default btn-block">Send Verification</button>
								</td>
							</tr>
						</table>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection