@extends('layouts.exmanager_template')
@section('exmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Notification Messages For Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			 @include('external_schoolmanagers.verifications.verifybox')
			<div class="col-md-9">
			@if(session('success'))
			<div class="alert alert-success">
				{{ session('success') }}
			</div>
			@endif
				<panel class="panel-body">
					
						@forelse($verfsendbox as $verfsend)
							<div class="media">
								<p><b>Send By:</b> {{ $verfsend->sender_name }}</p>
								<div class="media-body">
									<div class="well">
										{{ $verfsend->message }}
									</div>
								</div>
								<div class="media-footer">
									<div class="row">
									<div class="col-md-6"><font size="2px"><b>Status:</b> {{ ($verfsend->status == 0) ?'Not viewed':'Viewed '.$verfsend->updated_at->diffForHumans() }}</font></div>
									<div class="col-md-6"> 
										<ol class="breadcrumb bcs">
							              
							             
							             <li>
							             <form action="/exschoolremoveoutboxmsg/{{$verfsend->verf_id}}">
							              	{{ csrf_field() }}
							              	{{ method_field('DELETE') }}
												<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span> Trash </button>
										  </form>
							              </li>
							             
							              <li>
							              @if(!empty($verfsend->documents))
							              <a href="{{asset('storage/verifications/' . $verfsend->documents)}}" download="{{ $verfsend->documents }}" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-download"></span> Download</a>
							              @endif

							              </li>
							            </ol>
				            		</div>
								</div>
								</div>
							</div>
						<hr>
						@empty
						 No request Sent.
						@endforelse
						{{$verfsendbox->links()}}
					
				</panel>
				
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection