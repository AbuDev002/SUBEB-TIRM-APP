<div class="col-md-3">
<div class="panel panel-default">
	<div class="panel-heading topbar">
		<font color="white">Notifications</font>
	</div>
	<div class="panel-body">
		<ul class="notify">
		<li class="{{Request::is('exschoolverification') ? "active" : ""}}"><a href="/exschoolverification" class="btn btn-default btn-sm">Compose New</a></li>
		<li class="{{Request::is('exschoolinbox') ? "active" : ""}}"><a href="/exschoolinbox" class="btn btn-default btn-sm">Inbox Messages &nbsp;({{$total_outbox->count()}})</a></li>
		<li class="{{Request::is('exschoolsendbox') ? "active" : ""}}"><a href="/exschoolsendbox" class="btn btn-default btn-sm">Send Messages &nbsp;({{$total_inbox->count()}})</a></li>
	</ul>
	</div>
</div>
</div>