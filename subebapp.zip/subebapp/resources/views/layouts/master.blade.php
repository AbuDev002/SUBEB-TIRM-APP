<!DOCTYPE html>
<html lang="en">
  <head>
  <title>Bauchi State Universal Basic Education Board (SUBEB)</title>
<link rel="shortcut icon" href="images/fav.jpg" type="image/jpg">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
   <link rel="stylesheet" href="css/font-awesome.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
  <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <meta name="csrf-token" content="{{ csrf_token() }}">
</head>
  <body>
    @include('layouts.top-menu')
    <div class="container">
      @yield('content')
    </div> <!-- /container -->
  <!--<script src="js/jquery.js"></script>-->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
  <script type="text/javascript">
    function toggleZoomScreen() {
    document.body.style.zoom="80%"
    } 
</script>
  @yield('scripts')
  </body>
</html>
