<!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top topbar">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <table>
            <tr>
              <td><img src="images/logo.jpg" width="45" height="45" class="img-circle pull-left">&nbsp; &nbsp; &nbsp;</td>
              <td>
          <a class="navbar-brand" href="/"><span class="text-info"><font color="white">Teachers & Infrastructural Resource Management Portal</font></span></a></td>
            </tr>
          </table>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <!--<ul class="nav navbar-nav">
            <li class="active"><a href="/">Home</a></li>
            <li><a href="#about">About</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>-->
          <!--<ul class="nav navbar-nav navbar-right">
          @if(Sentinel::check())
             <li role="presentation">
              <form action="/logout" method="post" id="logout-form">
                {{ csrf_field() }}
                <a href="#" onclick="document.getElementById('logout-form').submit()">Logout</a>
              </form> 
            </li>

          @else
            <li class="active"><a href="/login">Login</span></a></li>
            <li><a href="/register">Register</a></li>
          @endif
          </ul>-->
        </div><!--/.nav-collapse -->
      </div>
    </nav>