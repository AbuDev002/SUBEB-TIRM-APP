@extends('layouts.smanager_template')
@section('schoolmanager-content')
<div class="panel panel-default">
			<div class="panel-heading special">
				&nbsp; &nbsp; &nbsp; <font color="white">List of Teachers</font>
			</div>
			<div class="panel-body">
				<p>
				@if(Session::has('success'))
					<div class="alert alert-success">
						<strong>Success</strong> {{ Session::get('success') }}
					</div>

				@endif
			</p>
			<h4><u>Teachers Currently Posted To  ({{Sentinel::getUser()->school['school_name']}}</u>)</h4>
			<table class="table table-bordered">
				<tr>
					<td>Schools</td>
					<td>Teachers</td>
				</tr>
				
			</table>
			</div>
		</div>
@endsection
@section('scripts')
	
@endsection