@extends('layouts.smanager_template')
@section('schoolmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Infrastructures</font>
	</div>
	<div class="panel-body">
		<ol class="breadcrumb">
		  <li><a href="/schoolnewinfrustructure">Add Infrastructure</a></li>
		</ol>
		<hr/>
		<table class="table table-bordered">
				<tr>
					<td><b>Project</b></td>
					<td><b>School Awarded To</b></td>
					<td><b>Sponsored by</b></td>
					<td><b>Year Awarded</b></td>
				</tr>
			@forelse($infrus as $infru)
				<tr>
					<td>{{ $infru->projectorinf_name}}</td>
					<td>{{ $infru->school->school_name}}</td>
					<td>{{ $infru->sponsored}}</td>
					<td>{{ $infru->yearawarded}}</td>
					<td><a href="/schoolinfrudetails/{{ $infru->inf_id }}" class="btn btn-default btn-sm">View Details</a></td>
					<td><a href="/schooleditinfru/{{ $infru->inf_id }}/schooleditinfru" class="btn btn-default btn-sm">Edit</a></td>
				</tr>
			@empty
				No Infrastructure/Facility record available
			@endforelse
		</table>
	</div>
</div>
@endsection

@section('scripts')
	
@endsection