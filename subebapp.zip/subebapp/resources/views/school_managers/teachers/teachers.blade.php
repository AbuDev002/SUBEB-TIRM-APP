@extends('layouts.smanager_template')
@section('schoolmanager-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Teacher's Record</font> 
	</div>
	<div class="panel-body">
	@if(session('success'))
	<div class="alert alert-success">
		{{ session('success') }}
	</div>
	@endif
	@forelse($teachers as $teacher)
	 	<table class="table table-condensed table-bordered">
                                   
			<tr>
				<td rowspan="6" width="150">
					@if(!empty($teacher->passport))
						<img src="{{asset('storage/upload/' . $teacher->passport)}}" class="img-thumbnail" width="150" height="150" />
					@else
						@if($teacher->gender =='Male')
                            <img src="/images/avarter.png" class="img-thumbnail" width="150" height="150" />

                        @else
                            <img src="/images/feavarter.png" class="img-thumbnail" width="150" height="150" />
                        @endif
					@endif
				</td>
				<th>PSN</th>
				<td>{{ $teacher->teacher_no }}</td>
			</tr>
			<tr>
				<th>Full Name</th>
				<td>{{ $teacher->surname }} {{ $teacher->firstname }} {{ $teacher->othername }}</td>
			</tr>
			
			<tr>
				<th>Phone</th>
				<td>{{ $teacher->phone }}</td>
				
			</tr>
	        <tr>
				<th width="250">Registered On</th>
				<td>{{ date('M j, Y h:ia', strtotime($teacher->created_at)) }}</td>
				
			</tr>
			<tr>
				<th width="250">Last Updated</th>
				<td>{{ date('M j, Y h:ia', strtotime($teacher->updated_at)) }}</td>
				
			</tr>
			<tr>
				<td><a href="/schoolviewteacher/{{ $teacher->id }}" class="btn btn-default btn-sm">View Details</a></td>
			</tr>
			
		</table>
	@empty
		No Teacher Available Yet.	

	@endforelse
	{{ $teachers->links() }}
	</div>
</div>
@endsection

@section('scripts')
	
@endsection