<div class="col-md-3">
<div class="panel panel-default">
	<div class="panel-heading topbar">
		<font color="white">Notifications</font>
	</div>
	<div class="panel-body">
		<ul class="notify">
		<li class="{{Request::is('schoolverification') ? "active" : ""}}"><a href="/schoolverification" class="btn btn-default btn-sm">Compose New</a></li>
		<li class="{{Request::is('schoolinbox') ? "active" : ""}}"><a href="/schoolinbox" class="btn btn-default btn-sm">Inbox Messages &nbsp;({{$total_outbox->count()}})</a></li>
		<li class="{{Request::is('schoolsendbox') ? "active" : ""}}"><a href="/schoolsendbox" class="btn btn-default btn-sm">Send Messages&nbsp;({{$total_inbox->count()}})</a></li>
	</ul>
	</div>
</div>
</div>