@extends('layouts.sadmin_template')
@section('superadmin-content')
		<div class="panel panel-default">
			<div class="panel-heading special">
				&nbsp; &nbsp; &nbsp; <font color="white">Welcome to SUBEB Administrative Panel</font>
			</div>
			<div class="panel-body">
				<p>
				@if(Session::has('success'))
					<div class="alert alert-success">
						<strong>Success</strong> {{ Session::get('success') }}
					</div>

				@endif
			</p>
			<table class="table table-bordered">
				<tr>
					<td>Schools</td>
					<td>Teachers</td>
				</tr>
				<tr>
					<td><a href="/sadminschool"><img src="../images/school-icon.png" width="50" height="50"></a></td>
					<td><a href="/sadminteachers"><img src="../images/teachers.png" width="50" height="50"></a></td>
				</tr>
				<tr>
					<td>Users</td>
					<td>Reports</td>
				</tr>
				<tr>
					<td><a href="/userspage"><img src="../images/group.png" width="50" height="50"></a></td>
					<td><a href="/sadminreport"><img src="../images/report.ico" width="50" height="50"></a></td>
				</tr>
			</table>
			</div>
		</div>
@endsection
