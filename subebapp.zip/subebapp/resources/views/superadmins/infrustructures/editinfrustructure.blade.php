@extends('layouts.sadmin_template')
@section('superadmin-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Add Infrastructure</font>
	</div>
	<div class="panel-body">
		<div class="well well-sm">
			 {{ Form::model($infru, ['url' => ['/seditinfru', $infru->inf_id]]) }}  
						@if(session('success'))
						<div class="alert alert-success">
							{{ session('success') }}
						</div>
						@endif
						<table class="table table-bordered" style="width:50%" align="center">
							<tr>
								<td width="200" align="right"><b>Project/Infrastructure</b></td>
								<td><!-- <input type="text" name="projectorinf_name" placeholder="Infrustructure/Facility..." style="width:100%;" required> -->
									 {{ Form::text('projectorinf_name',null, ["style" => 'width:100%']) }}
								</td>
							</tr>
							<tr>
								<td align="right"><b>School Awarde to:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option value="{{$infru->sch_id}}">{{ $infru->school->school_name }}</option>
								    	@foreach($schools as $school)
											<option value="{{ $school->sch_id}}">{{ $school->school_name}}</option>
								    	@endforeach
								 	</select>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Project Description:</b></td>
								<td>
									<!-- <textarea name="project_description" placeholder="Project description..." style="height:100px; width:100%;" required></textarea> -->
									{{ Form::textarea('project_description',null, ["style" => 'width:100%;','rows' =>'4']) }}
								</td>
							</tr>
							<tr>
								<td width="200" align="right"><b>No of Items</b></td>
								<td><!-- <input type="text" name="no_of_items" placeholder="No of items..." style="width:100%;" required> -->
									 {{ Form::text('no_of_items',null, ["style" => 'width:100%']) }}
								</td>
							</tr>
							<tr>
								<td align="right"><b>Year Awarded</b></td>
								<td>
									<!-- <input type="text" name="yearawarded" placeholder="YYYY-MM-DD" style="width:100%;" required> -->
									 {{ Form::text('yearawarded',null, ["style" => 'width:100%']) }}
								</td>
							</tr>
							<tr>
								<td align="right"><b>Sponsored By</b></td>
								<td>
									<!-- <input type="text" name="sponsored" placeholder="Sponsor..." style="width:100%;" required> -->
									 {{ Form::text('sponsored',null, ["style" => 'width:100%']) }}
								</td>
							</tr>
							<tr>
								<td align="right"><b>Name of Contractor</b></td>
								<td>
									<!-- <input type="text" name="contractor" placeholder="Enter name of contractor..." style="width:100%;" required> -->
									{{ Form::text('contractor',null, ["style" => 'width:100%']) }}
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default btn-block">Update Infrastructure</button>
								</td>
							</tr>
						</table>
						
					 {!! Form::close() !!}  
		</div>

	</div>
</div>
@endsection

@section('scripts')
	
@endsection