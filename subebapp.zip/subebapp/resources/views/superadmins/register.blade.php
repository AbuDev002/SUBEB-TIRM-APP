@extends('layouts.sadmin_template')
@section('superadmin-content')
		<div class="panel panel-default">
			<div class="panel-heading special">
				&nbsp; &nbsp; &nbsp; <font color="white">Create New User</font>
			</div>
			<div class="panel-body">
			<ol class="breadcrumb">
			  <li><strong>Add new user:&nbsp;</strong><span class="text-info">Your are adding new user to the system</span></li>
			</ol>
			@if(session('success'))
						<div class="alert alert-success">
							{{ session('success') }}
						</div>
						@endif
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
			<div class="panel panel-default">
				<div class="panel-body">
				<div class="well well-sm">
					<form action="/register" method="post" data-parsley-validate>
						{{ csrf_field()}}
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
								<input type="email" name="email" class="form-control" placeholder="example@example.com" required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user"></i></span>
								<input type="text" name="first_name" class="form-control" placeholder="Enter firstname..." required>
								
							</div>
						</div>
						
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-user"></i></span>
								<input type="text" name="last_name" class="form-control" placeholder="Enter lastname..." required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
							<label for="sel1">User Type:</label>
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
								<select class="form-control" id="sel1" name="user_type" required>
								    <option>--Select--</option>
								    <option value="super_admin">Super Administrator</option>
								    <option value="admin">Administrator</option>
								    <option value="school_manager">Schools Adminstrator</option>
								    <option value="external_manager">External Schools Adminstrator</option>
								  </select>
							</div>
						</div>

						<div class="form-group">
							<div class="input-group">
							<label for="sel1">School:</label>
								<!--<span class="input-group-addon"><i class="fa fa-user"></i></span>-->
								<select class="form-control" id="sel1" name="sch_id" style="width:100%;" required>
								    <option>--Select--</option>
								    @foreach($schools as $school)
										<option value="{{ $school->sch_id}}">{{ $school->school_name}}</option>

								    @endforeach
								  </select>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-map-marker"></i></span>
								<input type="text" name="location" class="form-control" placeholder="Enter location..." required>
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="password" class="form-control" placeholder="Enter password..." required>
								
							</div>
						</div>
						<div class="form-group">
							<div class="input-group">
								<span class="input-group-addon"><i class="fa fa-lock"></i></span>
								<input type="password" name="confirm-password" class="form-control" placeholder=" Confirm password..." required>
								
							</div>
						</div>
						<div class="form-group">
								<button type="submit" class="btn btn-default pull-right">Add User</button>
						</div>
					</form>
					<br>
					<br>
				</div>
				</div>
			</div>
				</div>
			</div>
		</div>	
	</div>
@endsection