@extends('layouts.sadmin_template')
@section('superadmin-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">{{ $school->school_name}}</font>
	</div>
	<div class="panel-body">
		<p><strong>LGA</strong> {{ $school->lga }}</p>
		<p><strong>Address</strong> {{ $school->sch_location }}</p>
		<p><strong>School Principal</strong> </p>
		
		<p><strong>Number of Students</strong> </p>
		<hr/>
		<h4><u>Infrusturcture & Project Done By SUBEB</u></h4>
			@forelse($infrus as $infru)
				<div class="media">
								<p><b>{{ $infru->projectorinf_name }}</b></p>
								<div class="media-body">
									<div class="well">
										{{ $infru->project_description }}
									</div>
								</div>
								<div class="media-footer">
									<div class="row">
									<div class="col-md-6"></div>
									<div class="col-md-6"> 
									<ol class="breadcrumb bcs">
						              <li><b>Sponsored By: </b>{{ $infru->sponsored }}</li>
						              <li><b>Contractor: </b>{{ $infru->contractor }}</li>
						              <li><b>Year Awarded: </b>{{ $infru->yearawarded }}</li>
						            </ol>
				            		</div>
								</div>
								</div>
							</div>
							<hr>
			@empty
				<p class="text-danger">No infrustructure/facilites available for this school</p>
			@endforelse
		
		<h4><u>Teachers Currently serving in the school</u></h4>
		<table class="table table-bordered">
			
			@forelse($teachers as $teacher)
			<tr>
				<td>{{ $teacher->teacher_no}}</td>
				<td>{{ $teacher->surname}} {{ $teacher->firstname}} {{ $teacher->othername}}</td>
				<td>{{ $teacher->phone}}</td>
				<td><a href="/sviewteacher/{{ $teacher->id }}" class="btn btn-default btn-sm">View Details</a></td>
			<td><a href="/seditteacher/{{ $teacher->id }}/editTeacher" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span>Edit</a></td>
			</tr>
			@empty
				<p class="text-danger">No teacher currently serving in this school</p>
			@endforelse

		</table>
		<p><strong>Number of Staffs</strong> ({{$teachers->count()}})</p>
		{{$teachers->links()}}
	</div>
</div>
@endsection

@section('scripts')
	
@endsection