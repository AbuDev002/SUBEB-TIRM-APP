@extends('layouts.sadmin_template')
@section('superadmin-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Registered Schools</font>
	</div>
	<div class="panel-body">
	<table class="table table-bordered">
		<tr>
			<td  style="width:60%;"><span class="text-info">This is where you can managed all school registered under SUBEB</span></td>
			<td><input type="text" id="search_school" name="search_school" placeholder="Search School..." class="form-control" style="width:100%;"></td>
		</tr>
	</table>
<ol class="breadcrumb">
  <li><a href="/snewschool">Add School</a></li>
  <li></li>
</ol>
@if(Session::has('success'))
            <div class="alert alert-success">
                <p><strong>Success</strong> {{ Session::get('success') }}</p>
            </div>

        @endif
 <table class="table table-bordered">
		<tbody id="thebody">
			<div class="alert alert-danger" style="display:none;">Sorry! no school found matching your search...</div>			
		</tbody>
   </table>
<table class="table table-bordered">

  	@forelse($schools as $school)
		<tr>
			<td>{{ $school->school_name}}</td>
			<td>{{ $school->sch_location}}</td>
			<td><a href="/sviewschool/{{ $school->sch_id }}" class="btn btn-default btn-sm">View Details</a></td>
			<td><a href="/seditschool/{{ $school->sch_id }}/editschool" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span></a></td>
			<td>
				<form action="/sremoveschool/{{$school->sch_id}}">
	          	{{ csrf_field() }}
	          	{{ method_field('DELETE') }}
					<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span></button>
			</form>
			</td>
		</tr>
	@empty
		No School Available.
  	@endforelse
  </table>
  {{ $schools->links() }}
	</div>
</div>

@endsection

@section('scripts')
	<script type="text/javascript">
		$('#search_school').on('keyup', function(){

			$value = $(this).val();
			$.ajax({
				type: 'GET',
				url: '{{URL::to('sadminschoolsearch')}}',
				data: {'search_school': $value},
				success:function(data){
					if(data !==""){
						$('#thebody').html(data);
						$('.alert-danger').hide();
					}else{
						$('.alert-danger').show();
					}
				}
			});
		})
	</script>
@endsection