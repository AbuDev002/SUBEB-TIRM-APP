@extends('layouts.sadmin_template')
@section('superadmin-content')
	<div class="panel panel-default">
		<div class="panel-heading special">
			&nbsp; &nbsp; &nbsp; <font color="white">Send Email</font>
		</div>
		<div class="panel-body">
		<div class="row">
			<div class="col-md-10  col-md-offset-1">
				<form action="/sendemail" method="POST" data-parsley-validate>
			{{ csrf_field()}}
			<div class="form-group">
				<label for="email" name="email">From:</label>
				<input type="text" id="email" name="email" style="width:100%" required>
			</div>
			<div class="form-group">
				<label for="emailto" name="email">Email To:</label>
				<input type="text" id="emailto" name="emailto" style="width:100%" required>
			</div>
			<div class="form-group">
				<label for="subject" name="subject">Subject:</label>
				<input type="text" id="subject" name="subject" style="width:100%" required>
			</div>
			<div class="form-group">
				<label for="message" name="message">Message</label>
				<textarea class="ckeditor" id="message" name="message" ></textarea>
			</div>
			<div class="form-group">
					<input type="submit" value="Send" class="btn btn-default btn-block">
				</div>
			</form>
			</div>
		</div>
		</div>
	</div>
@endsection

@section('scripts')
	<script type="text/javascript" src="js/tinymce/tinymce.min.js"></script>
 <script>
   tinymce.init({
    selector: 'textarea',
    height: 200,
    theme: 'modern',
    menubar: false,
    /*plugins: [
      'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      'searchreplace wordcount visualblocks visualchars code fullscreen',
      'insertdatetime media nonbreaking save table contextmenu directionality',
      'emoticons template paste textcolor colorpicker textpattern imagetools'
    ],*/
    toolbar1: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
    toolbar2: 'print preview media | forecolor backcolor emoticons',
    image_advtab: true,
    templates: [
      { title: 'Test template 1', content: 'Test 1' },
      { title: 'Test template 2', content: 'Test 2' }
    ],
    content_css: [
      '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
      '//www.tinymce.com/css/codepen.min.css'
    ]
   });
 </script>
@endsection