@extends('layouts.sadmin_template')
@section('superadmin-content')
	<div class="panel panel-default">
		<div class="panel-heading special">
			&nbsp; &nbsp; &nbsp; <font color="white">List of Users</font>
		</div>
		<div class="panel-body">
			<ol class="breadcrumb">
		  <li><a href="/register">Add User</a></li>
		  <li><span class="text-info">These are the users that are currently registered on the system</span></li>
		</ol>
		@if(session('success'))
		<div class="alert alert-success">
			{{ session('success') }}
		</div>
		@endif
		<table class="table table-bordered">
			<tr>
				<td colspan="5"><h4></h4></td>
			</tr>
			@forelse ($listofUsers as $lusers)
			<tr>
				<td>{{ $lusers->email }}</td>
				<td>{{ $lusers->first_name }}</td>
				<td>{{ $lusers->school['school_name'] }}</td>
				<td><b>Last Login: </b>{{$lusers->last_login}}</td>
				<td><a href="/edituser/{{$lusers->id}}" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-pencil"></span></a></td>
				<td>
					<form action="/sremoveuser/{{$lusers->id}}">
				          	{{ csrf_field() }}
				          	{{ method_field('DELETE') }}
							<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span></button>
					</form>
				</td>
			</tr>
			@empty
				No User registered yet.
			@endforelse
		</table>
		{{ $listofUsers->links() }}
		</div>
	</div>
@endsection
