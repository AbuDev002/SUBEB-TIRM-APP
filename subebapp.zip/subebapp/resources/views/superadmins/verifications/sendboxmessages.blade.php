@extends('layouts.sadmin_template')
@section('superadmin-content')
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Notification Messages For Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			 @include('superadmins.verifications.verifybox')
			<div class="col-md-9">
			@if(session('success'))
			<div class="alert alert-success">
				{{ session('success') }}
			</div>
			@endif
				<panel class="panel-body">
					
						@forelse($verfsendbox as $verfsend)
							<div class="media">
								<p><b>Send By:</b> {{ $verfsend->sender_name }}</p>
								<div class="media-body">
									<div class="well">
										{{ $verfsend->message }}
									</div>
								</div>
								<div class="media-footer">
									<div class="row">
									<div class="col-md-6"><font size="2px"><b>Status:</b> {{ ($verfsend->status == 0) ?'Not viewed':'Viewed '.$verfsend->updated_at->diffForHumans()}}</font></div>
									<div class="col-md-6"> 
										<ol class="breadcrumb bcs">
							              
							             
							             <li>
							             <form action="/sremoveoutboxmsg/{{$verfsend->verf_id}}">
							              	{{ csrf_field() }}
							              	{{ method_field('DELETE') }}
												<button class="btn btn-default btn-sm"><span class="glyphicon glyphicon-trash"></span> Trash </button>
										  </form>
							              </li>
							             
							              <li>
										@if(!empty($verfsend->documents))
							              <a href="{{asset('storage/verifications/' . $verfsend->documents)}}" download="{{ $verfsend->documents }}" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-download"></span> Download</a>
										@endif
							             </li>
							            </ol>
				            		</div>
								</div>
								</div>
							</div>
						<hr>
						@empty
						 No request Sent.
						@endforelse
						{{$verfsendbox->links()}}
					
				</panel>
				
			</div>
		</div>
	</div>
</div>
@endsection

@section('scripts')
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()
			

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
@endsection