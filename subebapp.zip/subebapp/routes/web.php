<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::group(['middleware' => 'visitors'], function(){
	Route::get('/','LoginController@login');

	Route::get('/login','LoginController@login');

	Route::post('/login','LoginController@postLogin');

	Route::get('/forgot-password','ForgotPasswordController@forgotPassword');

	Route::post('/forgot-password','ForgotPasswordController@postForgotPassword');

	Route::get('/reset/{email}/{resetCode}','ForgotPasswordController@resetPassword');

	Route::post('/reset/{email}/{resetCode}','ForgotPasswordController@postResetPassword');

});

Route::post('/logout','LoginController@logout');


//All super administrators routes will be assigned here
Route::group(['middleware' => 'super_admin'], function(){
	Route::get('/superadmin','SuperAdministratorController@dashBoard');
	Route::get('/userspage','SuperAdministratorController@usersPage');
	Route::get('/sremoveuser/{id}','SuperAdministratorController@sdeleteUser');
	Route::get('/edituser/{id}','SuperAdministratorController@editUser');
	Route::post('/edituser/{id}/edit_user','SuperAdministratorController@updateUser');
	Route::get('/register','RegistrationController@register');
	Route::post('/register','RegistrationController@postRegister');

	//super admin email routes
	Route::get('/sendemail', 'SuperAdministratorController@sendMail');
	Route::post('/sendemail', 'SuperAdministratorController@postMail');
	

	// Super Admin teachers route
	Route::get('/sadminteachers','TeachersController@sTeachersList');
	Route::get('/snewteacher','TeachersController@saddTeacher');
	Route::post('/snewteacher','TeachersController@sstoreTeacher');
	Route::get('/sviewteacher/{id}','TeachersController@sviewTeacher');
	Route::get('/seditteacher/{id}/editTeacher','TeachersController@seditTeacher')->name('supdated');
	Route::post('/seditteacher/{id}','TeachersController@supdateTeacher');
	Route::get('/sremoveteacher/{id}','TeachersController@sdeleteTeacher');
	
	// Super Adminschools route
	Route::get('/sadminschool','SchoolsController@sSchoolsList');
	Route::get('/snewschool','SchoolsController@saddSchool');
	Route::post('/sadminschool','SchoolsController@spostSchool');
	Route::get('/sviewschool/{id}','SchoolsController@sviewSchool');
	Route::get('/seditschool/{id}/editschool','SchoolsController@seditSchool')->name('scustomschool');
	Route::post('/seditschool/{id}','SchoolsController@supdateSchool');
	Route::get('/sremoveschool/{id}','SchoolsController@sdeleteSchool');

	// Super Admin infrustructure routes
	Route::get('/sadminfrustructure','InfrustructureController@sInfrsuctructuresList');
	Route::get('/snewinfrustructure','InfrustructureController@screateInfrustructure');
	Route::post('/snewinfrustructure','InfrustructureController@sstoreInfrustructure');
	Route::get('/sinfrudetails/{id}','InfrustructureController@sviewInfrustructure');
	Route::get('/seditinfru/{id}/editinfru','InfrustructureController@seditInfrustructure')->name('scustominfru');
	Route::post('/seditinfru/{id}','InfrustructureController@supdateInfrustructure');

	//Super Verfication and notification route
	Route::get('/sinbox','VerficationController@sinboxNotificationInadmin');
	Route::get('/sremoveinboxmsg/{id}','VerficationController@sdeleteInbox');
	Route::get('/ssendbox','VerficationController@ssendboxNotificationInadmin');
	Route::get('/sremoveoutboxmsg/{id}','VerficationController@sdeleteOutbox');
	Route::get('/smarkasreadmsg/{id}','VerficationController@smarkAsread');
	Route::get('/sadminverification','VerficationController@sverificationPage');
	Route::post('/sadminverification','VerficationController@spostVerification');

	//super admin search route
	Route::get('/sadminsearch','SearchController@sgetAdminSearchResult');
	Route::get('/sadminschoolsearch','SearchController@getsAdminSchoolSearchResult');

	//Super admin sms route
	Route::get('/sadminsms','smsController@ssmsPage');
	
	//Super Admin allocation routes
	Route::get('/sadminallocation','AllocationsController@allocationPage');

	// Super Admin reprots routes
	Route::get('/sadminreport','reportsController@sreportPage');
	Route::get('/sadminallstaffpdf','PDFController@sAllstaffgetPDF');
	Route::get('/sadminstafflgapdf','PDFController@sgetLgaPDF');
	//Route::get('/adminschreport','reportsController@gettLgaPDF');
	Route::get('/sadminschoolpdf','PDFController@sgetSchoolsPDF');
	Route::get('/sadminbankspdf','PDFController@sgetBanksPDF');
	Route::get('/sadminqualificationspdf','PDFController@sgetQualificationPDF');
});

//All admins route will be asinged here
Route::group(['middleware' => 'admin'], function(){
	Route::get('/admindashboard','AdminController@dashBoard');
	Route::get('/createuser','AdminController@register');
	Route::post('/createuser','AdminController@postRegister');
	Route::post('/post','postsController@store');
	Route::get('/userslist','AdminController@usersList');
	
	// Admin teachers route
	Route::get('/adminteachers','TeachersController@TeachersList');
	Route::get('/newteacher','TeachersController@addTeacher');
	Route::post('/newteacher','TeachersController@storeTeacher');
	Route::get('/viewteacher/{id}','TeachersController@viewTeacher');
	Route::get('/editteacher/{id}/editTeacher','TeachersController@editTeacher')->name('updated');
	Route::post('/editteacher/{id}','TeachersController@updateTeacher');
	
	
	// Adminschools route
	Route::get('/adminschool','SchoolsController@SchoolsList');
	Route::get('/newschool','SchoolsController@addSchool');
	Route::post('/adminschool','SchoolsController@postSchool');
	Route::get('/viewschool/{id}','SchoolsController@viewSchool');
	Route::get('/editschool/{id}/editschool','SchoolsController@editSchool')->name('customschool');
	Route::post('/editschool/{id}','SchoolsController@updateSchool');

	// Admin infrustructure routes
	Route::get('/adminfrustructures','InfrustructureController@InfrsuctructuresList');
	Route::get('/newinfrustructure','InfrustructureController@createInfrustructure');
	Route::post('/newinfrustructure','InfrustructureController@storeInfrustructure');
	Route::get('/infrudetails/{id}','InfrustructureController@viewInfrustructure');
	Route::get('/editinfru/{id}/editinfru','InfrustructureController@editInfrustructure')->name('customizeinfru');
	Route::post('/editinfru/{id}','InfrustructureController@updateInfrustructure');

	//Admin Verfication and notification route
	Route::get('/inbox','VerficationController@inboxNotificationInadmin');
	Route::get('/removeinboxmsg/{id}','VerficationController@deleteInbox');
	Route::get('/sendbox','VerficationController@sendboxNotificationInadmin');
	Route::get('/removeoutboxmsg/{id}','VerficationController@deleteOutbox');
	Route::get('/markasreadmsg/{id}','VerficationController@markAsread');
	Route::get('/adminverification','VerficationController@verificationPage');
	Route::post('/adminverification','VerficationController@postVerification');

	//admin search route
	Route::get('/adminsearch','SearchController@getAdminSearchResult');
	Route::get('/adminschoolsearch','SearchController@getAdminSchoolSearchResult');

	//admin sms route
	Route::get('/adminsms','smsController@smsPage');

	//Admin email routes
	Route::get('/adminemails','AdminController@emailsPage');
	Route::post('/adminemails','AdminController@postMail');
	
	//Admin allocation routes
	Route::get('/adminallocation','AllocationsController@allocationPage');

	//Admin reprots routes
	Route::get('/adminschreport','reportsController@reportPage');
	Route::get('/adminallstaffpdf','PDFController@AllstaffgetPDF');
	Route::get('/adminstafflgapdf','PDFController@getLgaPDF');
	//Route::get('/adminschreport','reportsController@gettLgaPDF');
	Route::get('/adminschoolpdf','PDFController@getSchoolsPDF');
	Route::get('/adminbankspdf','PDFController@getBanksPDF');
	Route::get('/adminqualificationspdf','PDFController@getQualificationPDF');
		
});


//All school managers routes will be assigned here
Route::group(['middleware' => 'school_manager'], function(){
	Route::get('/schoolmanager','TeachersController@SchoolTeachersList');
	Route::get('/schoolviewteacher/{id}','TeachersController@SchoolviewTeacher');

	// School infrustructure routes
	Route::get('/schoolfrustructures','InfrustructureController@SchoolInfrsuctructuresList');
	Route::get('/schoolnewinfrustructure','InfrustructureController@SchoolcreateInfrustructure');
	Route::post('/schoolnewinfrustructure','InfrustructureController@SchoolstoreInfrustructure');
	Route::get('/schoolinfrudetails/{id}','InfrustructureController@SchoolviewInfrustructure');
	Route::get('/schooleditinfru/{id}/schooleditinfru','InfrustructureController@SchooleditInfrustructure')->name('schoolcustomizeinfru');
	Route::post('/schooleditinfru/{id}','InfrustructureController@SchoolupdateInfrustructure');

	//School Verfication and notification route
	Route::get('/schoolinbox','VerficationController@SchoolinboxNotificationInadmin');
	Route::get('/schoolremoveinboxmsg/{id}','VerficationController@SchooldeleteInbox');
	Route::get('/schoolsendbox','VerficationController@SchoolsendboxNotificationInadmin');
	Route::get('/schoolremoveoutboxmsg/{id}','VerficationController@SchooldeleteOutbox');
	Route::get('/schoolmarkasreadmsg/{id}','VerficationController@SchoolmarkAsread');
	Route::get('/schoolverification','VerficationController@SchoolverificationPage');
	Route::post('/schoolverification','VerficationController@SchoolpostVerification');

	//School email routes
	Route::get('/schoolemails','SchoolManagersController@SchoolemailsPage');
	Route::post('/schoolemails','SchoolManagersController@SchoolpostMail');

	//School Search route
	Route::get('/schoolsearch','SearchController@getSchoolSearchResult');

	//School sms route
	Route::get('/schoolsms','smsController@SchoolsmsPage');

});


//All external school managers routes will be assigned here
Route::group(['middleware' => 'external_manager'], function(){
	//Route::get('/externalmanager','ExternalSchoolManagersController@dashBoard');
	Route::get('/externalmanager','TeachersController@ExSchoolTeachersList');
	Route::get('/exschoolviewteacher/{id}','TeachersController@ExSchoolviewTeacher');

	// External School infrustructure routes
	Route::get('/exschoolfrustructures','InfrustructureController@ExSchoolInfrsuctructuresList');
	Route::get('/exschoolnewinfrustructure','InfrustructureController@ExSchoolcreateInfrustructure');
	Route::post('/exschoolnewinfrustructure','InfrustructureController@ExSchoolstoreInfrustructure');
	Route::get('/exschoolinfrudetails/{id}','InfrustructureController@ExSchoolviewInfrustructure');
	Route::get('/exschooleditinfru/{id}/schooleditinfru','InfrustructureController@ExSchooleditInfrustructure')->name('exschoolcustomizeinfru');
	Route::post('/exschooleditinfru/{id}','InfrustructureController@ExSchoolupdateInfrustructure');

	//External School Verfication and notification route
	Route::get('/exschoolinbox','VerficationController@ExSchoolinboxNotificationInadmin');
	Route::get('/exschoolremoveinboxmsg/{id}','VerficationController@ExSchooldeleteInbox');
	Route::get('/exschoolsendbox','VerficationController@ExSchoolsendboxNotificationInadmin');
	Route::get('/exschoolremoveoutboxmsg/{id}','VerficationController@ExSchooldeleteOutbox');
	Route::get('/exschoolmarkasreadmsg/{id}','VerficationController@ExSchoolmarkAsread');
	Route::get('/exschoolverification','VerficationController@ExSchoolverificationPage');
	Route::post('/exschoolverification','VerficationController@ExSchoolpostVerification');

	//External School email routes
	Route::get('/exschoolemails','ExternalSchoolManagersController@ExSchoolemailsPage');
	Route::post('/exschoolemails','ExternalSchoolManagersController@ExSchoolpostMail');

	//External School Search route
	Route::get('/exschoolsearch','SearchController@ExgetSchoolSearchResult');

	//External School sms route
	Route::get('/exschoolsms','smsController@ExSchoolsmsPage');
});


//This route is sending email to users mails for him to activate his/her account have suspended it function for now
Route::get('/activate/{email}/{activationCode}','ActivationController@activate');
