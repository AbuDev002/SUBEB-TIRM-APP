<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<title>Report</title>
	<link rel="stylesheet" href="/css/bootstrap.css" />
	<link rel="stylesheet" href="/css/bootstrap-min.css" />

<style type="text/css">
	.page-break {
	    page-break-after: always;
	}
	#container{
		width:750px;
		height:auto;
		margin:0px auto;
		text-indent:5px;
                       
	}
	
	table{
		border-collapse: collapse;
	}
	.head{
	background:#91C5D4;
	}
	@page  { margin: 180px 50px; }
	#header { position: fixed; left: -45px; top: -180px; right: -45px; height: 135px; background-color: #f5f5f5; text-align: center; width:100%; }
	#footer { position: fixed; left: -45px; bottom: -180px; right: -45px; height: 45px; background-color: #f5f5f5; }
	#footer .page:after { content: counter(page, upper-roman); }
/*p { page-break-after: always; }*/
	.footer { position: fixed; bottom: 0px; }
	.pagenum:before { content: counter(page); }
  
</style>
</head>
<body>
<div id="header">
	<table  align="center"  width="100%">
		<tr>
			
			<td colspan="3" align="center"><h3>BAUCHI STATE UNIVERSAL BASIC EDUCATION BOARD<br/> <i> Ran Road, Near Awala Hotel Roundabout Bauchi, Bauchi State PMB 0109</i></h3></td>
		</tr>
		<tr>
			<td colspan="3" align="center" width="50">
				<?php $image_path = '/images/logo.jpg'; ?>
				<img src="<?php echo e(public_path() . $image_path); ?>" with="50" height="50">
			</td>
		</tr>
	</table>
</div>
<div id="footer">
		<hr/>
		<?php echo e(date('Y/m/d')); ?> / &nbsp; &nbsp; Page: <span class="pagenum">
</div>	
	<div id="container">
			<?php $__currentLoopData = $schs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<center><p><b><u>Teachers Serving in <?php echo e($sch->school_name); ?> as at (<?php echo e(date('Y-m-d')); ?>)</u></b></p></center>
			<table class="table table-bordered" align="center" border="1" width="90%">
				<tr>
					<td width="20"><b>S/N</b></td>
					<td width="50"><b>PSN No.</b></td>
					<td><b>Name</b></td>
					<td><b>Sex</b></td>
					<td><b>Phone</b></td>
				</tr>
				 <?php $i = 0 ?>
				<?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<?php $i++ ?>
				<tr>
					<td><?php echo e($i); ?></td>
					<td><?php echo e($teacher->teacher_no); ?></td>
					<td><?php echo e($teacher->surname); ?> <?php echo e($teacher->firstname); ?> <?php echo e($teacher->othername); ?></td>
					<td><?php echo e($teacher->gender); ?></td>
					<td><?php echo e($teacher->phone); ?></td>
				</tr>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<br>
					<center><p>No Teacher Available</p></center>
				<?php endif; ?>
			</table>
	</div>
</body>
</html>