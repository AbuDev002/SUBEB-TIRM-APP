<?php $__env->startSection('exmanager-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Staffs Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			<?php echo $__env->make('external_schoolmanagers.verifications.verifybox', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="col-md-9">
				<div class="well well-sm">
					<form action="/exschoolverification" method="post" enctype="multipart/form-data" data-parsley-validate>
						<?php echo e(csrf_field()); ?>

						<?php if(session('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session('success')); ?>

						</div>
						<?php endif; ?>
						<hr/>
						<input type="hidden" name="message_from" value="<?php echo e(Sentinel::getUser()->sch_id); ?>">
						<table class="table table-bordered" style="width:100%">
							<tr>
								<td align="right"><b>Sender Name:</b></td>
								<td><input type="text" name="sender_name" placeholder="Enter sender name..." style="width:100%;" required></td>
							</tr>
							
							<tr>
								<td align="right"><b>School to Send Request:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option>--Select School--</option>
								    	<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($school->sch_id); ?>"><?php echo e($school->school_name); ?></option>

								    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 	</select>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Message:</b></td>
								<td>
									<textarea name="message" placeholder="Write message..." style="height:100px; width:100%;"></textarea>
								</td>
							</tr>
							<tr>
								<td align="right"><b>Staff Credentials:</b></td>
								<td>
									<input type="file" name="credential">
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default btn-block">Send Verification</button>
								</td>
							</tr>
						</table>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.exmanager_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>