<?php $__env->startSection('admins-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Staffs Verification</font>
	</div>
	<div class="panel-body">
		<div class="row">
			<?php echo $__env->make('admins.verifybox', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
			<div class="col-md-9">
				<div class="well well-sm">
					<form action="/adminverification" method="post" enctype="multipart/form-data" data-parsley-validate>
						<?php echo e(csrf_field()); ?>

						<?php if(session('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session('success')); ?>

						</div>
						<?php endif; ?>
						<hr/>
						<input type="hidden" name="message_from" value="<?php echo e(Sentinel::getUser()->sch_id); ?>">
						<table class="table table-bordered" style="width:70%">
							<tr>
								<td width="200"><b>Sender Name:</b></td>
								<td><input type="text" name="sender_name" placeholder="Enter school name..." style="width:100%;" required></td>
							</tr>
							
							<tr>
								<td><b>School to Send Request:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option>--Select--</option>
								    	<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($school->sch_id); ?>"><?php echo e($school->school_name); ?></option>

								    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 	</select>
								</td>
							</tr>
							<tr>
								<td><b>Message:</b></td>
								<td>
									<textarea name="message" placeholder="Write message..." style="height:100px; width:100%;" required></textarea>
								</td>
							</tr>
							<tr>
								<td><b>Staff Credentials:</b></td>
								<td>
									<input type="file" name="credential" required>
								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default">Send Verification</button>
								</td>
							</tr>
						</table>
						
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript">
		$.ajaxSetup({
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			}
		});


		$('#login-form').submit(function(event){
			//This will not allow the form to submit
			event.preventDefault()
			

			var postData = {
				'email':$('input[name=email]').val(),
				'password':$('input[name=password]').val(),
				'remember_me':$('input[name=remember_me]').is(':checked'),
			}

			$.ajax({
				type: 'POST',
				url: '/login',
				data:  postData,
				success: function(response){
					$('.alert-success').show();
					window.location.href= response.redirect
				},
				error: function(response){
					$('.alert-danger').text(response.responseJSON.error)
					$('.alert-danger').show();
				}
			});
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>