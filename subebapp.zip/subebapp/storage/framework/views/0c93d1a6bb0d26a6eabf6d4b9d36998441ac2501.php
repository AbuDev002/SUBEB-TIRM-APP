<?php $__env->startSection('admins-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Teacher's Record</font> 
	</div>
	<div class="panel-body">
		<ol class="breadcrumb">
		  <li><a href="/newteacher">Add Teacher</a></li>
		</ol>
	<?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	 	<table class="table table-condensed table-bordered">
                                   
			<tr>
				<td rowspan="6" width="150">
					<?php if(!empty($teacher->passport)): ?>
						<img src="<?php echo e(asset('storage/upload/' . $teacher->passport)); ?>" class="img-thumbnail" width="150" height="150" />
					<?php else: ?>
						<?php if($teacher->gender =='Male'): ?>
							<img src="/images/avarter.png" class="img-thumbnail" width="150" height="150" />

						<?php else: ?>
							<img src="/images/feavarter.png" class="img-thumbnail" width="150" height="150" />
						<?php endif; ?>
					<?php endif; ?>
				</td>
				<th>PSN</th>
				<td><?php echo e($teacher->teacher_no); ?></td>
			</tr>
			<tr>
				<th>Full Name</th>
				<td><?php echo e($teacher->surname); ?> <?php echo e($teacher->firstname); ?> <?php echo e($teacher->othername); ?></td>
			</tr>
			
			<tr>
				<th>Phone</th>
				<td><?php echo e($teacher->phone); ?></td>
				
			</tr>
	        <tr>
				<th width="250">Registered On</th>
				<td><?php echo e(date('M j, Y h:ia', strtotime($teacher->created_at))); ?></td>
				
			</tr>
			<tr>
				<th width="250">Last Updated</th>
				<td><?php echo e(date('M j, Y h:ia', strtotime($teacher->updated_at))); ?></td>
				
			</tr>
			<tr>

				<td><a href="/viewteacher/<?php echo e($teacher->id); ?>" class="btn btn-default btn-sm">View Details</a></td>
			<td><a href="/editteacher/<?php echo e($teacher->id); ?>/editTeacher" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span>Edit</a></td>
				
			</tr>
			
		</table>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		No Teacher Available Yet.	

	<?php endif; ?>
	<?php echo e($teachers->links()); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>