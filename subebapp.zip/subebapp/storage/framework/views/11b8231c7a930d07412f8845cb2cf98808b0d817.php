<?php $__env->startSection('schoolmanager-content'); ?>
<div class="panel panel-default">
			<div class="panel-heading special">
				&nbsp; &nbsp; &nbsp; <font color="white">List of Teachers</font>
			</div>
			<div class="panel-body">
				<p>
				<?php if(Session::has('success')): ?>
					<div class="alert alert-success">
						<strong>Success</strong> <?php echo e(Session::get('success')); ?>

					</div>

				<?php endif; ?>
			</p>
			<h4><u>Teachers Currently Posted To  (<?php echo e(Sentinel::getUser()->school['school_name']); ?></u>)</h4>
			<table class="table table-bordered">
				<tr>
					<td>Schools</td>
					<td>Teachers</td>
				</tr>
				
			</table>
			</div>
		</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.smanager_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>