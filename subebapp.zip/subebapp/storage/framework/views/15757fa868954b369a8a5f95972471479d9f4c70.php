<?php $__env->startSection('superadmin-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white"><?php echo e($school->school_name); ?></font>
	</div>
	<div class="panel-body">
		<p><strong>LGA</strong> <?php echo e($school->lga); ?></p>
		<p><strong>Address</strong> <?php echo e($school->sch_location); ?></p>
		<p><strong>School Principal</strong> </p>
		
		<p><strong>Number of Students</strong> </p>
		<hr/>
		<h4><u>Infrusturcture & Project Done By SUBEB</u></h4>
			<?php $__empty_1 = true; $__currentLoopData = $infrus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="media">
								<p><b><?php echo e($infru->projectorinf_name); ?></b></p>
								<div class="media-body">
									<div class="well">
										<?php echo e($infru->project_description); ?>

									</div>
								</div>
								<div class="media-footer">
									<div class="row">
									<div class="col-md-6"></div>
									<div class="col-md-6"> 
									<ol class="breadcrumb bcs">
						              <li><b>Sponsored By: </b><?php echo e($infru->sponsored); ?></li>
						              <li><b>Contractor: </b><?php echo e($infru->contractor); ?></li>
						              <li><b>Year Awarded: </b><?php echo e($infru->yearawarded); ?></li>
						            </ol>
				            		</div>
								</div>
								</div>
							</div>
							<hr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<p class="text-danger">No infrustructure/facilites available for this school</p>
			<?php endif; ?>
		
		<h4><u>Teachers Currently serving in the school</u></h4>
		<table class="table table-bordered">
			
			<?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<tr>
				<td><?php echo e($teacher->teacher_no); ?></td>
				<td><?php echo e($teacher->surname); ?> <?php echo e($teacher->firstname); ?> <?php echo e($teacher->othername); ?></td>
				<td><?php echo e($teacher->phone); ?></td>
				<td><a href="/sviewteacher/<?php echo e($teacher->id); ?>" class="btn btn-default btn-sm">View Details</a></td>
			<td><a href="/seditteacher/<?php echo e($teacher->id); ?>/editTeacher" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span>Edit</a></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<p class="text-danger">No teacher currently serving in this school</p>
			<?php endif; ?>

		</table>
		<p><strong>Number of Staffs</strong> (<?php echo e($teachers->count()); ?>)</p>
		<?php echo e($teachers->links()); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sadmin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>