<?php $__env->startSection('admins-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Search Result</font>
	</div>
	<div class="panel-body">
		<p>Your search for "<?php echo e(Request::input('admin_search')); ?>"</p>

		<table class="table table-bordered">
			<?php $__empty_1 = true; $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<tr>
					<td><?php echo e($teacher->teacher_no); ?></td>
					<td><?php echo e($teacher->firstname); ?> <?php echo e($teacher->surname); ?></td>
					<td><?php echo e($teacher->email); ?></td>
					<td><a href="/viewteacher/<?php echo e($teacher->id); ?>" class="btn btn-default btn-sm">View Details</a></td>
					<td><a href="/editteacher/<?php echo e($teacher->id); ?>/editTeacher" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-edit"></span>Edit</a></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
				<p class="text-danger">No result found, sorry</p>
			
			<?php endif; ?>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>