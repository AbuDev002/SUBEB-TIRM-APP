<h1>Hello</h1>
<p>Plese click on the following link to reset your password
<a href="<?php echo e(env('APP_URL')); ?>/reset/<?php echo e($user->email); ?>/<?php echo e($code); ?>">Click here!</a>
</p>