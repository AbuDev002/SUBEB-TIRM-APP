<?php 
  function current_page($url = "/"){
    return request()->path() == $url;
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <title>SUBEB Super Administrator</title>
<link rel="shortcut icon" href="images/fav.jpg" type="image/jpg">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
   <link rel="stylesheet" href="css/font-awesome.css" />
    <link rel="stylesheet" href="css/font-awesome.min.css" />
  <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" type="text/css" href="css/parsely.css">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>
  <body>
   <nav class="navbar navbar-default topbar">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar-collapse" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <img src="../images/logo.jpg" width="45" height="45" class="img-circle">&nbsp; &nbsp;
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="navbar-collapse">
      <ul class="nav navbar-nav">
        <li class="<?php echo e(Request::is('superadmin') ? "active" : ""); ?>"><a href="/superadmin"><i class="fa fa-tachometer fa-fw" aria-hidden="true"></i><span class="text-info"><font color="white">Dashboard</font></span><span class="sr-only">(current)</span></a></li>
         <li class="<?php echo e(Request::is('sadminteachers') ? "active" : ""); ?>"><a href="/sadminteachers"><span class="text-info"><font color="white">Teachers</font></span></a></li>
         <li class="<?php echo e(Request::is('schoolspage') ? "active" : ""); ?>"><a href="/schoolspage"><span class="text-info"><font color="white">Schools</font></span></a></li>
         <li class="<?php echo e(Request::is('userspage') ? "active" : ""); ?>"><a href="/userspage"><i class="fa fa-users fa-fw" aria-hidden="true"></i><span class="text-info"><font color="white">Users</font></span></a></li>
          <li class="<?php echo e(Request::is('/sadminreports') ? "active" : ""); ?>"><a href="/sadminreport"><span class="text-info"><font color="white">Reports</font></span></a></li>
      </ul>
      <form class="navbar-form navbar-left">
     <div class="form-group">
      <input type="text" class="form-control" size="45" placeholder="Find Something...."/>
      
        </div>
        <button type="submit" class="btn btn-default" style="margin-top:-9px;"><i class="fa fa-search fa-lg" aria-hidden="true"></i></button>
      </form>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><i class="fa fa-user fa-fw" aria-hidden="true"></i></a></li>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><span class="text-info"><font color="white"><?php echo e(Sentinel::getUser()->first_name); ?></font></span><span class="caret"></span></a>
          <ul class="dropdown-menu">
        <li><a href="#">Settings</a></li>
        <li><a href="#">Change Password</a></li>
        <li>
          <form action="/logout" method="post" id="logout-form">
            <?php echo e(csrf_field()); ?>

            <!--<a href="#" onclick="document.getElementById('logout-form').submit()">Logout</a>-->
            <input type="submit" value="Logout" style="display:block;width:100%;">
          </form> 
        </li>
          </ul>
        </li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
    <div class="container" style="border:1px solid silver;background:#fff; padding:0px;">
       <span class="pull-right" style="color:#4d0000;font-family: comic sans-serif"> Bauchi State SUBEB <strong>::::</strong> Teachers & Infrustructural Resource Management Portal &nbsp; &nbsp;</span>
       <hr>
        <div class="row">
          <?php echo $__env->make('superadmins.menu.side', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
          <div class="col-md-9">
            <?php echo $__env->yieldContent('superadmin-content'); ?>
           </div>
        </div>
       
    </div> <!-- /container -->
     <hr/>
    <center><p style="color:#fff;">Copyright &copy; <?php echo e(date('Y')); ?> All Rights Reserved SUBEB Bauchi</p></center>
    <hr/>
  <!--<script src="js/jquery.js"></script>-->
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script type="text/javascript" src="js/jquery-ui.js"></script>
  <script type="text/javascript" src="js/parseley.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
  
  <script type="text/javascript">
    function toggleZoomScreen() {
    document.body.style.zoom="80%"
    } 
</script>
  <?php echo $__env->yieldContent('scripts'); ?>
  </body>
</html>
