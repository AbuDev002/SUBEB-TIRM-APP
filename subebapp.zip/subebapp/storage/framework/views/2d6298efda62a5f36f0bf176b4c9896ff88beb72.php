<nav class="navbar navbar-default" role="navigation">
      
        <div class="navbar-header">
           <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <table class="table" style="padding:0px;">
            <tr>
              <td><a href="/"><img src="../images/logo.jpg" width="45" height="45" class="img-circle"></a></td>
              <td><a href="#" class="navbar-brand"><strong>Teachers & Infrustructure Resource Portal, Bauchi State Universal Basic Education Board (SUBEB)</strong></a></td>
            </tr>
          </table>
        </div>
        <div class="collapse navbar-collapse">
          <!--<ul class="nav navbar-nav">
            <li><a href="#">Timeline</a></li>
            <li><a href="#">Friends</a></li>
          </ul>
          <form class="navbar-form navbar-left" role="search" action="#">
            <div class="form-group">
              <input type="text" name="query" class="form-control" placeholder="Find Something">
              <button type="submit" class="btn btn-default">Search</button>
            </div>
          </form>
            <ul class="nav navbar-nav navbar-right">
              <li><a href="#">Help</a></li>
              <li><a href="#">Admin</a></li>
            </ul>-->
        </div>
     
    </nav>