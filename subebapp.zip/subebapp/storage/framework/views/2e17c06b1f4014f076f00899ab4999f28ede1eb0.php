<?php $__env->startSection('admins-content'); ?>
<div class="panel panel-default">
	<div class="panel-heading special">
		&nbsp; &nbsp; <font color="white">Add Infrustructure</font>
	</div>
	<div class="panel-body">
		<div class="well well-sm">
			 <?php echo e(Form::model($infru, ['url' => ['/editinfru', $infru->inf_id]])); ?>  
						<?php if(session('success')): ?>
						<div class="alert alert-success">
							<?php echo e(session('success')); ?>

						</div>
						<?php endif; ?>
						<table class="table table-bordered" style="width:50%" align="center">
							<tr>
								<td width="200"><b>Project/Infrustructure</b></td>
								<td><!-- <input type="text" name="projectorinf_name" placeholder="Infrustructure/Facility..." style="width:100%;" required> -->
									 <?php echo e(Form::text('projectorinf_name',null, ["style" => 'width:100%'])); ?>

								</td>
							</tr>
							<tr>
								<td><b>School Awarde to:</b></td>
								<td>
									<select  name="sch_id" style="width:300px" required>
								   	 	<option value="<?php echo e($infru->sch_id); ?>"><?php echo e($infru->school->school_name); ?></option>
								    	<?php $__currentLoopData = $schools; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $school): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($school->sch_id); ?>"><?php echo e($school->school_name); ?></option>
								    	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								 	</select>
								</td>
							</tr>
							<tr>
								<td><b>Project Description:</b></td>
								<td>
									<!-- <textarea name="project_description" placeholder="Project description..." style="height:100px; width:100%;" required></textarea> -->
									<?php echo e(Form::textarea('project_description',null, ["style" => 'width:100%;','rows' =>'4'])); ?>

								</td>
							</tr>
							<tr>
								<td width="200"><b>No of Items</b></td>
								<td><!-- <input type="text" name="no_of_items" placeholder="No of items..." style="width:100%;" required> -->
									 <?php echo e(Form::text('no_of_items',null, ["style" => 'width:100%'])); ?>

								</td>
							</tr>
							<tr>
								<td><b>Year Awarded</b></td>
								<td>
									<!-- <input type="text" name="yearawarded" placeholder="YYYY-MM-DD" style="width:100%;" required> -->
									 <?php echo e(Form::text('yearawarded',null, ["style" => 'width:100%'])); ?>

								</td>
							</tr>
							<tr>
								<td><b>Sponsored By</b></td>
								<td>
									<!-- <input type="text" name="sponsored" placeholder="Sponsor..." style="width:100%;" required> -->
									 <?php echo e(Form::text('sponsored',null, ["style" => 'width:100%'])); ?>

								</td>
							</tr>
							<tr>
								<td><b>Name of Contractor</b></td>
								<td>
									<!-- <input type="text" name="contractor" placeholder="Enter name of contractor..." style="width:100%;" required> -->
									<?php echo e(Form::text('contractor',null, ["style" => 'width:100%'])); ?>

								</td>
							</tr>
							<tr>
								<td></td>
								<td>
									<button type="submit" class="btn btn-default">Update Infrustructure</button>
								</td>
							</tr>
						</table>
						
					 <?php echo Form::close(); ?>  
		</div>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>